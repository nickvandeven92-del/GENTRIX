import type { CompositionPlan } from "@/lib/ai/build-homepage-plan";
import { LAYOUT_ARCHETYPES, type LayoutArchetype } from "@/types/layoutArchetypes";

export type BuildLayoutArchetypesPromptOptions = {
  /** Zelfde volgorde als \`_site_config.sections\` — voor ritme-instructies. */
  sectionOrder?: string[];
  /** Macro-compositie uit \`HomepagePlan\`; staat **boven** deze sectie-map. */
  compositionPlan?: CompositionPlan;
};

function buildSectionRhythmLines(
  map: Record<string, LayoutArchetype>,
  sectionOrder: string[],
): string {
  if (sectionOrder.length === 0) return "";
  return sectionOrder
    .map((id, i) => {
      const arch = map[id];
      const archHint = arch ? ` (\`${arch}\`)` : "";
      if (i === 0) {
        return `- **${id}**${archHint} — eerste band: maximale visuele spanning; nav + hero volgen het gekozen archetype (geen slap begin).`;
      }
      if (i % 2 === 1) {
        return `- **${id}**${archHint} — **dichtere** band: inhoudsritme (kolommen, tijdlijn, split met beeld) — **niet** automatisch “alles in kaarten”; typografie en uitlijning mogen de structuur dragen i.p.v. borders om elk blok.`;
      }
      return `- **${id}**${archHint} — **adem**-band: royale witruimte, open canvas of zacht tonal field; kan één sterk full-bleed beeld, zachte gradient of display-typografie als anker (geen lege witte vlakte zonder focus).`;
    })
    .join("\n");
}

/**
 * Prompt-blok: koppelt sectie-id’s aan layout-archetypes + slot-namen voor Claude HTML (`data-layout` / `data-slot`).
 *
 * Let op: archetypen zijn **geen** vrijbrief voor identieke `rounded-2xl border bg-*-50` tegels — volg ook het **compositie-mandaat** in §0A van de user-prompt (minstens één band moet qua ritme uitbreken).
 */
export function buildLayoutArchetypesPromptBlock(
  map: Record<string, LayoutArchetype>,
  options?: BuildLayoutArchetypesPromptOptions,
): string {
  const used = [...new Set(Object.values(map))];
  const slotLines = used.map((id) => {
    const c = LAYOUT_ARCHETYPES[id];
    const slots = c.slotOrder.map((s) => `\`${s}\``).join(", ");
    return `- **${id}** → slots (in volgorde): ${slots}`;
  });

  const sectionOrder =
    options?.sectionOrder?.length ? options.sectionOrder : Object.keys(map);

  const qr = options?.compositionPlan?.qualityReport;
  const qualityLine =
    qr != null
      ? `**Compositie-kwaliteit (intern):** score ${qr.score}/100${qr.fixes.length ? ` — aandacht: ${qr.fixes.slice(0, 3).join("; ")}` : ""}\n\n`
      : "";

  const compositionHeader = options?.compositionPlan
    ? `=== COMPOSITIE → LAYOUT (hiërarchie) ===

**Macro (al in SITE INTENT):** \`layout_archetype\` = \`${options.compositionPlan.layoutArchetype}\` — beschrijft de **paginahouding**. **Visuele spanning:** ${options.compositionPlan.visualTension}

${qualityLine}**Ondergeschikt:** \`_layout_archetypes\` hieronder koppelt **canonieke sectie-id’s** (uit \`_site_config.sections\`) aan concrete \`data-layout\` + \`data-slot\`. Dat is de **vertaling** van zones naar HTML-blokken — niet de omgekeerde richting. Kies innerlijke compositie (overlap, full-bleed, typografie) zodat het past bij \`visual_tension\` en \`motion_personality\`.

`
    : "";

  const rhythmBlock =
    sectionOrder.length > 0
      ? `

=== SECTION RHYTHM (page flow — follow _site_config.sections order) ===

Alternate visual **density** so the page is not one flat stack of identical boxed cards — denk **editorial page flow** (rust ↔ spanning), niet “component library”:

${buildSectionRhythmLines(map, sectionOrder)}
`
      : "";

  return `${compositionHeader}=== LAYOUT ARCHETYPES (structuur in HTML — ondergeschikt aan macro-compositie) ===

**Editorial note:** archetypes = **compositie + slot-semantiek** per sectie-id, niet “alles in \`surfaces.card\`”. Witruimte, type-schaal, overlap en full-bleed media gaan vóór boxed cards — in lijn met \`compositionPlan.visual_tension\`.

_layout_archetypes — koppelt elke **geplande sectie-\`id\`** (canoniek) aan precies één archetype-id (letterlijk op de buitenste \`<section>\`):

${JSON.stringify(map, null, 2)}

**Mandatory HTML attributes (in addition to \`id\` on the outer \`<section>\`):**

1. On the **outermost** \`<section>\` for each mapped section: add \`data-layout="<archetype-id>"\` using the value from \`_layout_archetypes\` for that section’s JSON \`id\`.
2. Wrap each **major** content block inside that section in a container (usually \`<div>\`) with \`data-slot="<slot-name>"\`. Slot names MUST come from the archetype’s list below. Use slots **top-to-bottom** in narrative order: first block → first slot, second → second slot, etc. If you have fewer blocks than slots, use the first N slots only. If you need more wrappers than slots, group related content inside one slotted wrapper.
3. Do not invent new \`data-layout\` or \`data-slot\` strings — only ids from this message.

**Navbar + hero (when \`data-layout\` starts with \`hero_nav_\`):**

- First slot is always \`navigation\`. Implement **one** distinctive pattern: centered links under wordmark, **floating pill** nav, **two-row** bar (brand row + link row), or **split** wordmark + vertical link stack — align with §0A nav mandates in the user prompt.
- **Forbidden as default:** lazy “logo left + inline links + CTA far right” unless nothing else fits the content.
- **\`hero_nav_split_product\`:** after \`navigation\`, \`media\` and \`content\` must sit **side-by-side from \`md:\`** (inner \`grid md:grid-cols-2\` or flex row); on mobile stack with media first or second per best UX.

**Split / grid archetypes:**

- **\`content_faq_two_column\`:** \`intro\` spans **full width** above the columns (\`md:col-span-2\` on the intro wrapper inside a grid, or intro outside the 2-col grid).
- **\`content_pricing_split_lead\`:** \`intro\` = copy column; \`plans_grid\` = pricing **offers** (één tier mag visueel uitgelicht; de rest mag rustiger/open — geen verplichte identieke drie “dozen”).
- **\`testimonials_split_spotlight\`:** \`spotlight_quote\` is the large focal quote; \`supporting_stack\` holds secondary quotes or logos — not three equal cards.
- **\`cta_floating_card\`:** interpreteer als **zwevend, compact UI-vlak** (pill/bar boven het canvas) — **niet** als excuus om de hele hero in een dikke bordered box te stoppen.

**BANNED boring patterns (even if Tailwind makes them easy):**

- Reusing the **same** “three equal icon cards” composition in both features **and** pricing **and** testimonials.
- **Pricing:** three identical cards with no scaled/emphasized plan when \`data-layout\` is \`content_pricing_comparison\` or \`content_pricing_split_lead\`.
- **Testimonials:** only one small centered card with carousel dots as the **entire** section when the archetype expects a wall, grid, or spotlight layout.
- **FAQ:** endless duplicate rectangles with zero intro band or typographic hierarchy.
- **Global:** long stretches of **flat** same-color background with no imagery, gradient, or preset \`effects.*\` treatment (see premium contract).
- **Global:** using \`border\` + \`rounded-2xl\` + \`shadow-lg\` op **elke** kolom als enige manier om inhoud te “groeperen” — dat voelt als standaard Tailwind-SaaS, niet als award-niveau.

**Slot reference (archetypes used in this run):**

${slotLines.join("\n")}
${rhythmBlock}
`;
}
