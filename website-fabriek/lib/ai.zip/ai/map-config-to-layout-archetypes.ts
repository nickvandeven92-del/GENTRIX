import type { SiteConfig } from "@/lib/ai/build-site-config";
import {
  buildStudioPromptLayoutMaps,
  type StudioPromptLayoutMapsOptions,
} from "@/lib/ai/studio-prompt-layout-maps";
import type { LayoutArchetype } from "@/types/layoutArchetypes";

/**
 * Per sectie-id een layout-archetype voor `data-layout` / `data-slot` in gegenereerde HTML.
 * `salt` = bijv. varianceNonce zodat elke run andere hero/features-variant kan kiezen.
 * `themeMode` uit `getDesignPreset(brand_style).themeMode` — lichte sites sluiten cinematic hero’s uit.
 * Zet `freeformSectionFraction` (0–1) in options voor dezelfde sparsity als site-generatie (zie `buildStudioPromptLayoutMaps`).
 */
export function mapConfigToLayoutArchetypes(
  config: SiteConfig,
  salt: string = "",
  options?: StudioPromptLayoutMapsOptions,
): Record<string, LayoutArchetype> {
  return buildStudioPromptLayoutMaps(config, salt, options).layoutArchetypes;
}
