/**
 * Enterprise-grade design-system **types** + generator-context.
 *
 * website-fabriek rendert nu Tailwind-HTML via Claude (JSON `config` + `sections`), geen React-tree.
 * Klassen zoals PreviewEngine / WebsiteGenerator horen hier **niet** — die zouden lege stubs zijn.
 * Gebruik deze types als contract voor: prompts, toekomstige token-JSON, of een aparte UI-builder.
 */

import type { ReactNode } from "react";
import type { DesignPreset as TailwindClassPreset } from "@/lib/ai/design-presets";

// --- 1. Core design tokens -------------------------------------------------

export type ColorScale = Record<50 | 100 | 200 | 300 | 400 | 500 | 600 | 700 | 800 | 900, string>;

export type DesignToken = {
  color: {
    primary: ColorScale;
    secondary: ColorScale;
    neutral: ColorScale;
    semantic: {
      success: string;
      error: string;
      warning: string;
      info: string;
    };
  };
  typography: {
    fontFamily: {
      sans: string;
      serif: string;
      mono: string;
    };
    fontSize: Record<
      "xs" | "sm" | "base" | "lg" | "xl" | "2xl" | "3xl" | "4xl" | "5xl" | "6xl" | "7xl" | "8xl",
      { size: string; lineHeight: string; letterSpacing?: string }
    >;
    fontWeight: Record<
      "thin" | "light" | "normal" | "medium" | "semibold" | "bold" | "extrabold" | "black",
      number
    >;
  };
  spacing: Record<
    | 0
    | 0.5
    | 1
    | 1.5
    | 2
    | 2.5
    | 3
    | 4
    | 5
    | 6
    | 8
    | 10
    | 12
    | 16
    | 20
    | 24
    | 32
    | 40
    | 48
    | 56
    | 64
    | 72
    | 80
    | 96,
    string
  >;
  animation: {
    duration: Record<"none" | "fast" | "normal" | "slow" | "slower", string>;
    timing: Record<"linear" | "ease" | "ease-in" | "ease-out" | "ease-in-out", string>;
    keyframes: Record<string, Record<string, unknown>>;
  };
  breakpoints: Record<"sm" | "md" | "lg" | "xl" | "2xl", string>;
};

// --- 2. Component architecture (voor app/admin; niet voor Claude-HTML output) -

export type ComponentVariant = "primary" | "secondary" | "outline" | "ghost" | "destructive";
export type ComponentSize = "xs" | "sm" | "md" | "lg" | "xl";

export interface BaseComponent {
  variant?: ComponentVariant;
  size?: ComponentSize;
  className?: string;
  disabled?: boolean;
  loading?: boolean;
}

export interface ButtonComponent extends BaseComponent {
  type?: "button" | "submit" | "reset";
  icon?: ReactNode;
  iconPosition?: "left" | "right";
  fullWidth?: boolean;
}

export interface CardComponent {
  padding?: ComponentSize;
  elevated?: boolean;
  interactive?: boolean;
  border?: boolean;
}

export interface FormComponent {
  layout?: "vertical" | "horizontal" | "inline";
  validation?: "onBlur" | "onChange" | "onSubmit";
  errorMessage?: string;
}

// --- 3. Layout --------------------------------------------------------------

export type GridConfig = {
  columns: number | Record<keyof DesignToken["breakpoints"], number>;
  gap: ComponentSize;
  rows?: number;
  autoRows?: "auto" | "min" | "max" | "minmax";
};

export type ContainerConfig = {
  maxWidth?: "sm" | "md" | "lg" | "xl" | "2xl" | "full";
  padding?: ComponentSize;
  center?: boolean;
  bleed?: boolean;
};

// --- 4. AI / generator context ----------------------------------------------

export interface GeneratorAIContext {
  projectType: "landing" | "ecommerce" | "dashboard" | "blog" | "portfolio" | "saas";
  brandPersonality: "professional" | "playful" | "luxury" | "minimal" | "tech";
  targetAudience: string[];
  seoKeywords: string[];
  accessibilityLevel: "A" | "AA" | "AAA";
  performanceTarget: "fast" | "blazing" | "instant";
}

export type AnimationConfig = {
  id: string;
  durationToken?: keyof DesignToken["animation"]["duration"];
  timingToken?: keyof DesignToken["animation"]["timing"];
};

export type InteractionConfig = {
  kind: "hover" | "focus" | "click" | "scroll";
  payload?: Record<string, unknown>;
};

/** Sectie-blauwdruk: parallel aan `mapConfigToComponents` + Tailwind snippets. */
export interface GeneratedSectionBlueprint {
  id: string;
  type: "hero" | "features" | "pricing" | "testimonials" | "cta" | "footer" | "gallery" | "contact";
  content: unknown;
  /** Huidige fabriek: utility-strings die naar Claude gaan (`design-presets`). */
  styles: TailwindClassPreset;
  animations: AnimationConfig[];
  interactions: InteractionConfig[];
}

// --- 5. Project / export (toekomst) ----------------------------------------

export interface WebsiteProject {
  id: string;
  name: string;
  tokens?: Partial<DesignToken>;
  context?: GeneratorAIContext;
  sections: GeneratedSectionBlueprint[];
}

// --- 6. Helpers -------------------------------------------------------------

export function serializeGeneratorAIContext(ctx: GeneratorAIContext): string {
  return JSON.stringify(ctx, null, 2);
}
