/** Vaste test-briefings voor handmatige of script-gestuurde kwaliteitschecks. */
export const BENCHMARK_PROMPTS = {
  saas: [
    "Maak een landing page voor een AI-powered CRM voor kleine bedrijven",
    "SaaS platform voor projectmanagement met focus op remote teams",
  ],
  ecommerce: [
    "Online winkel voor biologische huidverzorgingsproducten",
    "Mode-retailer voor duurzame kleding, met nadruk op zoeken en filters",
  ],
  editorial: [
    "Content hub voor recepten, met zoekfunctie en categorieën",
    "Tech blog met reviews, tutorials en nieuws",
  ],
  service: [
    "Barbier in Amsterdam, maak een leadgeneratie website",
    "Fysiotherapie praktijk met focus op afspraken maken",
  ],
  health: [
    "Gezondheidsblog met evidence-based artikelen over voeding",
    "Mental health platform met resources en zelfhulp tools",
  ],
} as const;
