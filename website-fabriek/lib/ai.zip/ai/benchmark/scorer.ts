import type { SiteExperienceModel } from "@/lib/ai/site-experience-model";
import { scoreOutputForExperienceModel } from "@/lib/ai/validate-generated-page";

export { scoreOutputForExperienceModel };

/** Gemiddelde score over meerdere HTML-fragmenten (bijv. per sectie). */
export function averageExperienceScore(htmlParts: string[], model: SiteExperienceModel): number {
  if (htmlParts.length === 0) return 0;
  const sum = htmlParts.reduce((acc, h) => acc + scoreOutputForExperienceModel(h, model), 0);
  return Math.round(sum / htmlParts.length);
}
