import type { HomepagePlan } from "@/lib/ai/build-homepage-plan";

import { EXPERIENCE_MODEL_PROMPT_HINTS } from "@/lib/ai/experience-model-prompt-hints";

import type { SiteIntent } from "@/lib/ai/site-experience-model";

import type { ValidationIssue } from "@/lib/ai/validate-homepage-plan";



export function buildSiteExperiencePromptBlock(params: {

  intent: SiteIntent;

  plan: HomepagePlan;

  planIssues?: ValidationIssue[];

}): string {

  const hint = EXPERIENCE_MODEL_PROMPT_HINTS[params.intent.experienceModel];

  const issuesNote =

    params.planIssues && params.planIssues.length > 0

      ? `\n\n=== PLAN CHECK (intern; los op in HTML-keuzes) ===\n${JSON.stringify(params.planIssues, null, 2)}`

      : "";



  const cp = params.plan.compositionPlan;



  return `=== PAGINA COMPOSITIE (leidend — geen losse secties renderen) ===



Je ontwerpt **één doorlopende pagina** met gewenste **dynamiek**, **visuele spanning** en **zones**. De JSON hieronder is de blauwdruk: vertaal dit naar HTML (Tailwind) zodat de scroll-ervaring klopt — niet: “hier is een lijst componenten die je elk in eenzelfde kaart stopt”.



**Experience model:** \`${params.plan.experienceModel}\`

**Strategie-hint:** ${hint}



**compositionPlan (macro — staat boven sectie-details en boven losse archetype-namen):**

${JSON.stringify(

  {

    macroComposition: cp.macroComposition,

    layout_archetype: cp.layoutArchetype,

    layout_dna: cp.layoutDNA,

    visual_tension: cp.visualTension,

    motion_personality: cp.motionPersonality,

    composition_quality: cp.qualityReport
      ? {
          score: cp.qualityReport.score,
          strengths: cp.qualityReport.strengths,
          fixes: cp.qualityReport.fixes.slice(0, 6),
        }
      : undefined,

    composition_zones: cp.compositionZones.map((z) => ({
      id: z.id,
      role: z.role,
      intent: z.intent,
      widthMode: z.widthMode,
      density: z.density,
      surfaceMode: z.surfaceMode,
      alignmentMode: z.alignmentMode,
      mediaPriority: z.mediaPriority,
      layoutEnergy: z.layoutEnergy,
      preferredPatterns: z.preferredPatterns,
      proofIntensity: z.proofIntensity,
      ctaIntensity: z.ctaIntensity,
      allowCards: z.allowCards,
      allowAsymmetricBalance: z.allowAsymmetricBalance,
      narrative: z.narrative,
    })),

  },

  null,

  2,

)}



**Section-level hints (ondergeschikt aan compositionPlan):** volgorde, prioriteit en dichtheid per logische band — te mappen op de **korte** lijst \`_site_config.sections\` (vaak ≤5): meerdere rollen mogen in **één** rijke \`<section>\` samenvallen als de zone-rollen en spanning zo beter uitkomen.



${JSON.stringify(

  {

    navigationModel: params.plan.navigationModel,

    trustModel: params.plan.trustModel,

    rhythm: params.plan.rhythm,

    sectionSequence: params.plan.sectionSequence,

    recommendedPattern: params.intent.recommendedHomepagePattern,

    businessModel: params.intent.businessModel,

    contentStrategy: params.intent.contentStrategy,

    searchImportance: params.intent.searchImportance,

  },

  null,

  2,

)}

${issuesNote}



**Regels:**

- **Eerst** zones + \`visual_tension\` + \`motion_personality\` vertalen naar het canvas; **daarna** \`sectionSequence\` en (in STUDIO STRUCTUUR) \`_layout_archetypes\` als concrete \`data-layout\`/\`data-slot\`-hints per canonieke sectie-id.

- Als \`searchPriority\` = high: zichtbare zoek-UI in de **discovery**-zone (hero of nav), passend bij \`layout_archetype\`.

- Respecteer \`rhythm\` verticaal: wissel compacte banden met luchtige banden — dat ondersteunt \`visual_tension\`.

- Gebruik **alleen** sectie-id’s uit \`_site_config.sections\` **zoals in dit bericht** (vrij: geplande lijst; upgrade: **gemergde** lijst = bestaand + gepland). **Geen** \`id\` verzinnen dat niet in die lijst staat.

`;

}


