import type { HomepagePlan } from "@/lib/ai/build-homepage-plan";
import type { SiteExperienceModel } from "@/lib/ai/site-experience-model";
import { buildContentClaimDiagnosticsReport } from "@/lib/ai/content-claim-diagnostics";

export type GeneratedPageValidation = {
  errors: string[];
  warnings: string[];
};

/**
 * Lichtgewicht HTML-checks op gejoinde sectie-HTML (geen DOM).
 * Geen auto-retry hier — caller kan loggen of later feedback-loop toevoegen.
 */
export function validateGeneratedPageHtml(html: string, plan: HomepagePlan): GeneratedPageValidation {
  const errors: string[] = [];
  const warnings: string[] = [];

  const buttonCount = (html.match(/<button\b/gi) ?? []).length;
  if (buttonCount > 10) {
    warnings.push(`Veel buttons (${buttonCount}); overweeg max ~8–10 voor rust.`);
  }

  const cardish = (html.match(/\bcard\b/gi) ?? []).length;
  const editorialLean =
    plan.experienceModel === "editorial_content_hub" ||
    plan.experienceModel === "brand_storytelling" ||
    plan.experienceModel === "premium_product";
  const cardBudget =
    plan.densityProfile === "dense_commerce" || plan.experienceModel === "ecommerce_home"
      ? 18
      : editorialLean
        ? 7
        : 10;
  if (cardish > cardBudget) {
    warnings.push(
      `Veel ‘card’-verwijzingen (${cardish}); editorial/premium richting: liever open canvas en type-led layout — zie preset + contract.`,
    );
  }

  const roundedBoxes = (html.match(/\brounded-(xl|2xl|3xl)\b/gi) ?? []).length;
  const borderHits = (html.match(/\bborder(?:-[a-z0-9]+)*\b/gi) ?? []).length;
  const softBgTiles = (html.match(/\bbg-(?:slate|gray|zinc)-50\b/gi) ?? []).length;
  if (roundedBoxes >= 14 && borderHits >= 12 && softBgTiles >= 4) {
    warnings.push(
      `Veel rounded-xl/2xl + borders + zachte grijze vlakken — typisch generieke ‘AI card wall’; overweeg full-bleed secties, type-led bands en minder kadertjes (zie §0A compositie-mandaat).`,
    );
  }

  if (!/<h1\b/i.test(html)) {
    errors.push("Geen <h1> gevonden (SEO/toegankelijkheid).");
  }

  const hasLargeHeading = /text-(6|7|8)xl\b/.test(html);
  if (!hasLargeHeading && plan.experienceModel !== "saas_landing") {
    warnings.push("Geen grote display-kop (text-6xl+); overweeg dramatische hero-typografie.");
  }

  if (plan.navigationModel.searchPriority === "high") {
    const hasSearchUi =
      /type\s*=\s*["']search["']/i.test(html) ||
      /\bsearch\b/i.test(html) && /input\b/i.test(html) ||
      /placeholder\s*=\s*["'][^"']*zoek/i.test(html);
    if (!hasSearchUi) {
      errors.push("Zoekprioriteit high maar geen duidelijke zoek-input/zoek-UI gevonden.");
    }
  }

  const layoutAttrs = (html.match(/\bdata-layout\s*=/g) ?? []).length;
  const expectedMin = Math.min(plan.sectionSequence.length, 12);
  if (layoutAttrs > 0 && layoutAttrs < Math.min(3, expectedMin)) {
    warnings.push(`Weinig data-layout attributen (${layoutAttrs}); elke <section> hoort data-layout uit de map.`);
  }

  const claimReport = buildContentClaimDiagnosticsReport(html);
  for (const c of claimReport.items) {
    const line = `[${c.severity === "error" ? "claim-error" : "claim-warn"} — ${c.code} @${c.index}] ${c.match}`;
    if (c.severity === "error") errors.push(line);
    else warnings.push(line);
  }

  return { errors, warnings };
}

/** Optionele score 0–100 voor benchmarks (los van productie-validator). */
export function scoreOutputForExperienceModel(html: string, model: SiteExperienceModel): number {
  let score = 0;
  if (/text-(6|7|8)xl\b/.test(html)) score += 10;
  if (/tracking-tight/.test(html)) score += 5;
  if (/font-(bold|black)\b/.test(html)) score += 5;
  if (/md:col-span-2\b|lg:col-span-2\b|grid-cols-2\b/.test(html)) score += 8;
  if (!/grid-cols-1\s+md:grid-cols-3\b/.test(html)) score += 5;
  if (/bg-gradient-to-/.test(html)) score += 10;
  if (/shadow-(xl|2xl)\b/.test(html)) score += 5;
  if (/blur-3xl\b/.test(html)) score += 8;
  if (model === "ecommerce_home" && /zoek|search|category|categor/i.test(html)) score += 15;
  if (model === "editorial_content_hub" && /article|verhaal|lees|story/i.test(html)) score += 15;
  if (model === "service_leadgen" && /afspraak|contact|boek|plan/i.test(html)) score += 15;
  return Math.min(100, score);
}
