import { buildAboveFoldPromptBlockFromInterpretation, getAboveFoldArchetypeAntiPatterns } from "@/lib/ai/above-fold-plan";
import {
  buildDesignRegimePromptBlock,
  buildHeroCharacterBlock,
  getEffectiveHeroExpression,
} from "@/lib/ai/above-fold-archetypes";
import {
  applyResolverConfidenceToLayoutOptions,
  type ResolverConfidenceLayoutOptions,
} from "@/lib/ai/apply-resolver-confidence-to-layout-options";
import { buildContentAuthorityPolicyBlock } from "@/lib/ai/content-authority-policy";
import type { SiteConfig } from "@/lib/ai/build-site-config";
import type { CompositionConflictDecision } from "@/lib/ai/resolve-composition-plan";
import type { HeroExpression, SiteIntent } from "@/lib/ai/site-experience-model";

const EXPRESSION_GUARDRAILS: Record<HeroExpression, readonly string[]> = {
  split_clear: [
    "Respect **split** legibility: media vs copy moeten onderscheidbaar blijven; geen éénkoloms-editorial als default tenzij `_layout_archetypes.hero` dat expliciet is.",
  ],
  integrated_hero: [
    "Geen klassieke 50/50 product-split als hoofdpatroon — media hoort **in** het geïntegreerde canvas (bento, editorial stack, cinematic).",
  ],
  integrated_campaign: [
    "Campagne-energie mag, maar **één** hiërarchische leeslijn; geen losse navbar-strip + los hero-kader zonder compositorische samenhang.",
  ],
  editorial_calm: [
    "Geen retail-urgentie of schreeuwerige promo-balken boven de fold; typografie en witruimte dragen de rust.",
  ],
  immersive_overlay: [
    "Statement + beeld domineren; **niet** de hero vullen met paragrafen of secundaire modules boven de fold.",
  ],
  showcase_visual: [
    "Visuele coördinatie boven generieke gallery-grid; geen identieke kaarten als enige eerste indruk.",
  ],
  commerce_dense: [
    "Dichtheid ja, maar **hiërarchie** eerst; geen vlakke categorie-card-muur zonder duidelijke held.",
  ],
  service_trust: [
    "Menselijk, vertrouwen, contact — geen agressieve transactionele druk; geen product-split alsof het een SKU is.",
  ],
  minimal_typographic: [
    "Minimaal aantal elementen; **verboden** om leegte op te vullen met decoratieve cards of iconenrijen.",
  ],
  balanced_mixed: [
    "Kies **één** duidelijke above-fold-modus en meng split- en integrated-slots niet willekeurig in één rommelige structuur.",
  ],
};

function baseGuardrailsForLayout(layout: ResolverConfidenceLayoutOptions): string[] {
  const core =
    "Wijk **niet** af van de gekozen `_layout_archetypes.hero` tenzij de briefing of upgrade-regels expliciet anders vereisen.";
  if (layout.biasStrength === "soft") {
    return [core, "Bij **lage** resolver-zekerheid: geen harde experimenten — maar **geen** overdreven archetype-lock; houd opties open."];
  }
  if (layout.biasStrength === "hard") {
    return [
      core,
      "Bij **hoge** zekerheid: volg de gekozen above-fold-lijn strak; vermijd willekeurige alternatieve hero-stijlen.",
    ];
  }
  return [core, "Bij **gemiddelde** zekerheid: veilige, bewezen hiërarchie waar twijfel bestaat."];
}

/**
 * Harde anti-patterns + expressie-specifieke regels + optioneel archetype-antipatterns uit resolver.
 */
export function buildAboveFoldGuardrailsBlock(
  siteIntent: SiteIntent,
  layoutOptions?: ResolverConfidenceLayoutOptions,
): string {
  const layout =
    layoutOptions ?? applyResolverConfidenceToLayoutOptions(siteIntent.resolverConfidence);
  const lines: string[] = ["=== ABOVE-FOLD GUARDRAILS ==="];
  const expr = getEffectiveHeroExpression(siteIntent);
  lines.push(`- **heroExpression:** ${expr}`);

  const rc = siteIntent.resolverConfidence;
  if (rc) {
    lines.push(`- **resolverConfidence:** ${rc.level} (score ${rc.score.toFixed(2)})`);
  }

  for (const g of baseGuardrailsForLayout(layout)) {
    lines.push(`- ${g}`);
  }
  for (const g of EXPRESSION_GUARDRAILS[expr]) {
    lines.push(`- ${g}`);
  }

  const arch = siteIntent.aboveFoldArchetypeId;
  if (arch) {
    lines.push("");
    lines.push("**Archetype anti-patterns (resolver):**");
    for (const a of getAboveFoldArchetypeAntiPatterns(arch)) {
      lines.push(`- ${a}`);
    }
  }

  return lines.join("\n");
}

export type BuildAboveFoldStrategyPromptBlockParams = {
  siteIntent: SiteIntent;
  siteConfig: Pick<SiteConfig, "prompt_interpretation_context">;
  layoutOptions?: ResolverConfidenceLayoutOptions;
  conflictsResolved?: string[];
  /** Gestructureerd: winnaar vs onderdrukt (dominantie). */
  conflictDecisions?: CompositionConflictDecision[];
};

function buildNoInterpretationAboveFoldDetailBlock(siteIntent: SiteIntent): string {
  const expr = getEffectiveHeroExpression(siteIntent);
  const lines: string[] = [
    "=== ABOVE THE FOLD SYSTEM (geen interpretatie-context) ===",
    `- **heroExpression:** ${expr} — zelfde lijn doorzetten **onder** de fold (niet alleen hero-decoratie).`,
    "- Gebruik **design regime** + **hero character** hierboven als canoniek spanningskader; geen tegenstrijdige retail-urgentie als expressie editorial/immersive is.",
    "- **Expressie-guardrails (volledig — geen token-besparing):**",
  ];
  for (const g of EXPRESSION_GUARDRAILS[expr]) {
    lines.push(`  - ${g}`);
  }
  return lines.join("\n");
}

function buildResolverStrengthInstruction(layout: ResolverConfidenceLayoutOptions): string {
  if (layout.biasStrength === "hard") {
    return "Behandel dit als een **sterke compositiedirective**: behoud consistentie met het gekozen above-fold-patroon en wijk **niet** af naar ongerelateerde hero-stijlen.";
  }
  if (layout.biasStrength === "soft") {
    return "Behandel dit als een **zachte hint**: behoud **flexibiliteit** en voorkom overfitting op één smal archetype.";
  }
  return "Behandel dit als een **voorkeursrichting**: waar mogelijk consistent, zonder starre lock-in.";
}

/**
 * Vervangt losse `buildDesignRegimePromptBlock` + above-fold v2 + guardrails: één strategieblok voor de studio-prompt.
 */
export function buildAboveFoldStrategyPromptBlock(params: BuildAboveFoldStrategyPromptBlockParams): string {
  const { siteIntent, siteConfig } = params;
  const ctx = siteConfig.prompt_interpretation_context;
  const layoutOptions =
    params.layoutOptions ?? applyResolverConfidenceToLayoutOptions(siteIntent.resolverConfidence);

  const head: string[] = [
    "=== ABOVE-FOLD STRATEGY ===",
    `- **heroExpression (effectief):** ${getEffectiveHeroExpression(siteIntent)}`,
    `- ${buildResolverStrengthInstruction(layoutOptions)}`,
  ];
  if (siteIntent.resolverConfidence) {
    const rc = siteIntent.resolverConfidence;
    head.push(`- **resolverConfidence:** ${rc.level} (${rc.score.toFixed(2)})`);
  }
  if (siteIntent.aboveFoldArchetypeId) {
    head.push(`- **aboveFoldArchetypeId:** ${siteIntent.aboveFoldArchetypeId}`);
  }
  if (params.conflictDecisions?.length) {
    head.push("- **Compositie-dominantie (geen middeling):**");
    for (const d of params.conflictDecisions) {
      head.push(
        `  - **Winnaar:** ${d.winningSignal} · **Onderdrukt:** ${d.suppressedSignal} — ${d.reason}`,
      );
    }
  } else if (params.conflictsResolved?.length) {
    head.push(`- **Compositor-normalisatie:** ${params.conflictsResolved.join("; ")}`);
  }
  head.push(
    "",
    buildDesignRegimePromptBlock(siteIntent),
    "",
    buildHeroCharacterBlock(siteIntent),
    "",
  );

  const compactFallback = `=== ABOVE THE FOLD SYSTEM (compact) ===
- ${buildResolverStrengthInstruction(layoutOptions)}
- Volg **heroExpression** en \`_layout_archetypes.hero\`; minder micro-sturing — details uit design regime hierboven.`;

  let detailBlock: string;
  if (layoutOptions.preferCompactFallbackPrompt) {
    detailBlock = compactFallback;
  } else if (ctx) {
    detailBlock = buildAboveFoldPromptBlockFromInterpretation(ctx.interpretation, ctx.profile, siteIntent);
  } else {
    detailBlock = buildNoInterpretationAboveFoldDetailBlock(siteIntent);
  }

  const guard = buildAboveFoldGuardrailsBlock(siteIntent, layoutOptions);
  const authority = buildContentAuthorityPolicyBlock();

  return [...head, detailBlock, "", guard, "", authority].join("\n");
}
