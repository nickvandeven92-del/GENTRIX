import type { CompactnessProfile } from "@/types/pageCompactness";
import type { SectionContentBudget } from "@/types/sectionContentBudget";

export type FooterMode = "compact" | "standard" | "expanded";

export type FooterContent = {
  brand: string;
  description?: string;
  address?: string;
  phone?: string;
  email?: string;
  serviceLinks?: string[];
  businessLinks?: string[];
  legalLinks?: string[];
};

export function resolveFooterMode(compactness: CompactnessProfile): FooterMode {
  if (!compactness.allowLargeFooter) return "compact";
  if (compactness.pageLengthTarget === "extended") return "expanded";
  return "standard";
}

export function buildFooterContent(
  input: FooterContent,
  mode: FooterMode,
  budget: SectionContentBudget,
): FooterContent {
  if (mode === "compact") {
    return {
      brand: input.brand,
      phone: input.phone,
      email: input.email,
      legalLinks: input.legalLinks?.slice(0, Math.min(3, budget.maxNavLinks)),
    };
  }

  if (mode === "standard") {
    return {
      ...input,
      serviceLinks: input.serviceLinks?.slice(0, Math.min(4, budget.maxNavLinks)),
      businessLinks: input.businessLinks?.slice(0, Math.min(3, budget.maxNavLinks)),
      legalLinks: input.legalLinks?.slice(0, Math.min(3, budget.maxNavLinks)),
    };
  }

  return {
    ...input,
    serviceLinks: input.serviceLinks?.slice(0, budget.maxNavLinks),
    businessLinks: input.businessLinks?.slice(0, budget.maxNavLinks),
    legalLinks: input.legalLinks?.slice(0, budget.maxNavLinks),
  };
}
