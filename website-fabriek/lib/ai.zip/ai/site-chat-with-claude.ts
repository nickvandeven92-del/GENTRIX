import Anthropic from "@anthropic-ai/sdk";
import type { ContentBlockParam, MessageParam } from "@anthropic-ai/sdk/resources/messages";
import { z } from "zod";
import { ANTHROPIC_KEY_MISSING_USER_HINT, getAnthropicApiKey } from "@/lib/ai/anthropic-env";
import { clampMaxTokensNonStreaming } from "@/lib/ai/anthropic-nonstream-limits";
import { getAlpineInteractivityPromptBlock } from "@/lib/ai/interactive-alpine-prompt";
import { getKnowledgeContextForClaude } from "@/lib/data/ai-knowledge";
import { parseModelJsonObject } from "@/lib/ai/extract-json";
import { logClaudeMessageUsage } from "@/lib/ai/log-claude-message-usage";
import {
  isLegacyTailwindPageConfig,
  masterPromptPageConfigSchema,
  sectionSemanticRoleSchema,
  type TailwindPageConfig,
  type TailwindSection,
} from "@/lib/ai/tailwind-sections-schema";

const DEFAULT_MODEL = "claude-sonnet-4-20250514";

const chatTurnSchema = z.object({
  role: z.enum(["user", "assistant"]),
  content: z.string().min(1).max(32000),
});

export const siteChatRequestMessagesSchema = z.array(chatTurnSchema).min(1).max(40);

const chatResponseSchema = z.object({
  reply: z.string().min(1).max(24000),
  sections: z
    .array(
      z.object({
        sectionName: z.string().max(200).optional(),
        html: z.string().min(1).max(120_000),
        semanticRole: sectionSemanticRoleSchema.optional(),
        copyIntent: z.string().max(500).optional(),
      }),
    )
    .min(1)
    .max(24)
    .optional(),
  config: masterPromptPageConfigSchema.optional(),
});

export type SiteChatTurn = z.infer<typeof chatTurnSchema>;

export type SiteChatResult =
  | {
      ok: true;
      reply: string;
      sections?: TailwindSection[];
      config?: TailwindPageConfig | null | undefined;
    }
  | { ok: false; error: string; rawText?: string };

function buildSitePayload(sections: TailwindSection[], config: TailwindPageConfig | null | undefined) {
  return {
    config: config ?? null,
    sections: sections.map((s, i) => ({
      index: i,
      sectionName: s.sectionName,
      html: s.html,
      semanticRole: s.semanticRole,
      copyIntent: s.copyIntent,
    })),
  };
}

function buildClaudeMessages(
  messages: SiteChatTurn[],
  currentPayload: ReturnType<typeof buildSitePayload>,
  attachmentUrls: string[],
  knowledgePrefixBlocks: ContentBlockParam[],
): MessageParam[] {
  const out: MessageParam[] = [];
  for (let i = 0; i < messages.length - 1; i++) {
    const m = messages[i];
    out.push({ role: m.role, content: m.content });
  }
  const last = messages[messages.length - 1];
  if (!last || last.role !== "user") {
    throw new Error("Laatste bericht moet van de gebruiker zijn.");
  }
  const attach =
    attachmentUrls.length > 0
      ? `\n\nGeüploade afbeelding-URL's (gebruik als src in <img> in de passende sectie, bijv. logo in header/hero):\n${attachmentUrls.map((u) => `- ${u}`).join("\n")}`
      : "";
  const tailText = `${last.content}${attach}\n\n---\nHuidige website (JSON, alle secties — dit is de waarheid voor deze beurt):\n${JSON.stringify(currentPayload)}\n---`;

  if (knowledgePrefixBlocks.length === 0) {
    out.push({ role: "user", content: tailText });
  } else {
    out.push({
      role: "user",
      content: [...knowledgePrefixBlocks, { type: "text", text: `\n\n=== SITE-CHAT (huidige beurt) ===\n\n${tailText}` }],
    });
  }
  return out;
}

function buildChatSystemPrompt(legacy: boolean): string {
  const configRule = legacy
    ? `Als je \`sections\` wijzigt: geen \`config\` in je antwoord (legacy-site).`
    : `Als de gebruiker kleuren/thema wil: je mag \`config\` (master: style, theme, font) meesturen. Anders weglaten.`;

  return `Je bent een vriendelijke Nederlandstalige assistent die een bestaande Tailwind-landingspagina helpt aanpassen.

${getAlpineInteractivityPromptBlock()}

GEDRAG:
- Beantwoord eerst helder in \`reply\` (markdown toegestaan in plain text).
- Wijzig de site **alleen** als de gebruiker dat expliciet vraagt of het duidelijk nodig is voor het verzoek. Als een puur inhoudelijke/vraag is zonder wijziging: laat \`sections\` weg.
- Als je wijzigt: lever **alle** secties terug in \`sections\`, **dezelfde volgorde en aantal** als in de JSON hierboven. Elk item minstens \`html\`.
- HTML-regels: geen \`<script>\`/\`<style>\` in fragmenten, geen klassieke inline handlers, geen javascript:-links; Alpine (\`x-*\`, \`@\`, \`:\`) volgens het blok hierboven. Alleen https voor afbeeldingen.
- Gebruik geüploade logo-URL's waar de gebruiker om vraagt.

OUTPUT: uitsluitend **één** JSON-object, geen markdown-fences eromheen:
{
  "reply": "je antwoord aan de gebruiker",
  "sections": [ ... ]  // optioneel
  "config": { ... }    // optioneel; ${configRule}
}`;
}

export async function siteChatWithClaude(
  messages: SiteChatTurn[],
  sections: TailwindSection[],
  config: TailwindPageConfig | null | undefined,
  attachmentUrls: string[],
): Promise<SiteChatResult> {
  const apiKey = getAnthropicApiKey();
  if (!apiKey) {
    return {
      ok: false,
      error: `ANTHROPIC_API_KEY ontbreekt in de omgeving. ${ANTHROPIC_KEY_MISSING_USER_HINT}`,
    };
  }

  const model = process.env.ANTHROPIC_MODEL ?? DEFAULT_MODEL;
  const client = new Anthropic({ apiKey });

  const legacy = config != null && isLegacyTailwindPageConfig(config);
  const currentPayload = buildSitePayload(sections, config);
  const { systemText: knowledge, userPrefixBlocks } = await getKnowledgeContextForClaude();
  const system = [knowledge, buildChatSystemPrompt(legacy)].filter(Boolean).join("\n\n---\n\n");
  const claudeMessages = buildClaudeMessages(messages, currentPayload, attachmentUrls, userPrefixBlocks);

  const message = await client.messages.create({
    model,
    max_tokens: clampMaxTokensNonStreaming(model, 24_576),
    system,
    messages: claudeMessages,
  });

  await logClaudeMessageUsage("site_chat", model, message.usage);

  const textBlock = message.content.find((b) => b.type === "text");
  if (!textBlock || textBlock.type !== "text") {
    return { ok: false, error: "Geen tekst-antwoord van Claude ontvangen." };
  }

  const parsedResult = parseModelJsonObject(textBlock.text);
  if (!parsedResult.ok) {
    const truncated =
      message.stop_reason === "max_tokens"
        ? " Antwoord mogelijk afgekapt (max_tokens)."
        : "";
    return {
      ok: false,
      error: `Antwoord is geen geldige JSON.${truncated}`,
      rawText: textBlock.text,
    };
  }
  const parsed = parsedResult.value;

  const validated = chatResponseSchema.safeParse(parsed);
  if (!validated.success) {
    return {
      ok: false,
      error: `JSON voldoet niet aan het schema: ${validated.error.message}`,
      rawText: textBlock.text,
    };
  }

  const { reply, sections: outSections, config: outConfig } = validated.data;

  if (!outSections) {
    return { ok: true, reply };
  }

  if (outSections.length !== sections.length) {
    return {
      ok: false,
      error: `Claude gaf ${outSections.length} secties terug; er zijn ${sections.length} nodig (zelfde volgorde).`,
      rawText: textBlock.text,
    };
  }

  const mergedSections: TailwindSection[] = outSections.map((s, i) => {
    const prev = sections[i];
    const row: TailwindSection = {
      sectionName: s.sectionName?.trim() || prev.sectionName,
      html: s.html,
    };
    const sr = s.semanticRole ?? prev.semanticRole;
    if (sr != null) row.semanticRole = sr;
    const ci = s.copyIntent ?? prev.copyIntent;
    if (ci != null) row.copyIntent = ci;
    return row;
  });

  let nextConfig: TailwindPageConfig | null | undefined = config;
  if (outConfig) {
    if (config != null && isLegacyTailwindPageConfig(config)) {
      nextConfig = config;
    } else {
      nextConfig = outConfig;
    }
  }

  return { ok: true, reply, sections: mergedSections, config: nextConfig };
}
