import { buildAboveFoldStrategyPromptBlock } from "@/lib/ai/above-fold-strategy-prompt";
import type { HomepagePlan } from "@/lib/ai/build-homepage-plan";
import type { ExtractedDesignFromImage, SiteConfig } from "@/lib/ai/build-site-config";
import type { DesignPreset } from "@/lib/ai/design-presets";
import { formatPersonalityPromptBlock } from "@/lib/ai/design-personality";
import { buildLayoutArchetypesPromptBlock } from "@/lib/ai/layout-archetypes-prompt";
import { LOVABLE_EXAMPLES_COMPACT } from "@/lib/ai/lovable-examples";
import { PREMIUM_DESIGN_SYSTEM_CONTRACT } from "@/lib/ai/premium-design-system-contract";
import { buildSiteExperiencePromptBlock } from "@/lib/ai/site-experience-prompt-block";
import type { ResolverConfidenceLayoutOptions } from "@/lib/ai/apply-resolver-confidence-to-layout-options";
import type { CompositionConflictDecision } from "@/lib/ai/resolve-composition-plan";
import type { SiteIntent } from "@/lib/ai/site-experience-model";
import type { ValidationIssue } from "@/lib/ai/validate-homepage-plan";
import type { LayoutArchetype } from "@/types/layoutArchetypes";

function clipPresetSnippet(s: string, max: number): string {
  const t = s.trim();
  return t.length <= max ? t : `${t.slice(0, max)}…`;
}

/** Korte herhaling vóór het volledige JSON: modellen volgen dit vaker dan een enorme nested blob alleen. */
export function buildDesignPresetPromptDigest(p: DesignPreset): string {
  return `=== PRESET DIGEST (zichtbaar toepassen in HTML — niet “plat” negeren) ===
- **themeMode:** ${p.themeMode}
- **surfaces:** page \`${clipPresetSnippet(p.surfaces.page, 90)}\` · section \`${clipPresetSnippet(p.surfaces.section, 90)}\` · sectionAlt \`${clipPresetSnippet(p.surfaces.sectionAlt, 90)}\`
- **card:** \`${clipPresetSnippet(p.surfaces.card, 130)}\` — *Editorial rule:* dit snippet is voor **focale** vlakken (uitgelichte tier, zwevende UI, compacte call-out), **niet** als standaard-wrapper om elke kolom of alinea. Open secties zonder zichtbare box mogen.
- **typography.heading:** \`${clipPresetSnippet(p.typography.heading, 150)}\`
- **buttons.primary:** \`${clipPresetSnippet(p.buttons.primary, 140)}\`
- **effects.gradient:** \`${clipPresetSnippet(p.effects.gradient, 120)}\`
- **effects.shadow / glow:** \`${clipPresetSnippet(p.effects.shadow, 100)}\` · \`${clipPresetSnippet(p.effects.glow, 100)}\`
- **navigation.wrapper:** \`${clipPresetSnippet(p.navigation.wrapper, 130)}\`
`;
}

/**
 * Prompt-blok: structuur + presets + component-mapping + strikt designcontract (naast kennisbank + §0A).
 */
export function buildStudioStructurePromptBlock(params: {
  siteConfig: SiteConfig;
  components: Record<string, string>;
  layoutArchetypes: Record<string, LayoutArchetype>;
  designPreset: DesignPreset;
  extractedFromImage?: ExtractedDesignFromImage | null;
  siteIntent: SiteIntent;
  homepagePlan: HomepagePlan;
  homepagePlanIssues?: ValidationIssue[];
  layoutOptions?: ResolverConfidenceLayoutOptions;
  compositionConflictsResolved?: string[];
  compositionConflictDecisions?: CompositionConflictDecision[];
}): string {
  const extractNote = params.extractedFromImage
    ? `

=== _vision_extract (samenvatting referentiebeeld; interpreted, not copied) ===
${JSON.stringify(params.extractedFromImage, null, 2)}
`
    : "";

  const layoutBlock = buildLayoutArchetypesPromptBlock(params.layoutArchetypes, {
    sectionOrder: params.siteConfig.sections,
    compositionPlan: params.homepagePlan.compositionPlan,
  });

  const experienceBlock = buildSiteExperiencePromptBlock({
    intent: params.siteIntent,
    plan: params.homepagePlan,
    planIssues: params.homepagePlanIssues,
  });

  const aboveFoldStrategyBlock = buildAboveFoldStrategyPromptBlock({
    siteIntent: params.siteIntent,
    siteConfig: params.siteConfig,
    layoutOptions: params.layoutOptions,
    conflictsResolved: params.compositionConflictsResolved,
    conflictDecisions: params.compositionConflictDecisions,
  });

  return `${formatPersonalityPromptBlock(params.siteConfig.personality)}

${experienceBlock}

${LOVABLE_EXAMPLES_COMPACT}

=== STUDIO STRUCTUUR (inputs) ===

_site_config (JSON):
${JSON.stringify(params.siteConfig, null, 2)}

=== CREATIVE OVERRIDE (geen invul-template) ===
- **Volgorde:** \`compositionPlan\` (SITE INTENT) bepaalt paginadynamiek, spanning en zones; \`_layout_archetypes\` / \`_component_variants\` zijn **sectie-niveau vertaling** — geen gelijkwaardige “checklist van bouwstenen”.
- \`_layout_archetypes\` en \`_component_variants\` zijn **richtinggevende hints**, geen mal. Als ze een voorspelbare SaaS-kaartenmuur opleveren, **herontwerp** je de compositie: sterkere typografie, open band, asymmetrie, of gecombineerde rollen in één sectie — binnen preset + PREMIUM CONTRACT.
- Secties die **niet** in \`_layout_archetypes\` voorkomen: ontwerp **vrij** (wel \`data-slot\` alleen als je zinvolle semantische blokken scheidt); geen verplichte card-grid.
- **Max. secties** staan in \`_site_config.sections\` — dat is bewust **kort**; zone-rollen en \`sectionSequence\` mag je **samenvatten** in minder HTML-secties.

${layoutBlock}

${aboveFoldStrategyBlock}

_component_variants (sectie-id → benoemd patroon):
${JSON.stringify(params.components, null, 2)}

${buildDesignPresetPromptDigest(params.designPreset)}
_design_preset (geneste utility-snippets — layout, typography, buttons, surfaces, navigation, effects, sections, colors):
${JSON.stringify(params.designPreset, null, 2)}
${extractNote}

---

${PREMIUM_DESIGN_SYSTEM_CONTRACT}`;
}

/**
 * Bij **upgrade / behoud lay-out** wordt geen volledige studio-JSON (preset + lovable) gedupliceerd,
 * maar de **composer** (macro-compositie + archetype-map) blijft zichtbaar — anders krijgt het model
 * geen `compositionPlan` en vallen alle sites terug op dezelfde SaaS-skeleton in §3.
 * Bestaande sectie-html komt uit de bron-JSON; dit blok stuurt vooral **nieuwe** secties en toon.
 */
export function buildStudioStructurePromptBlockForUpgrade(params: {
  siteConfig: SiteConfig;
  components: Record<string, string>;
  layoutArchetypes: Record<string, LayoutArchetype>;
  siteIntent: SiteIntent;
  homepagePlan: HomepagePlan;
  homepagePlanIssues?: ValidationIssue[];
  layoutOptions?: ResolverConfidenceLayoutOptions;
  compositionConflictsResolved?: string[];
  compositionConflictDecisions?: CompositionConflictDecision[];
}): string {
  const layoutBlock = buildLayoutArchetypesPromptBlock(params.layoutArchetypes, {
    sectionOrder: params.siteConfig.sections,
    compositionPlan: params.homepagePlan.compositionPlan,
  });
  const experienceBlock = buildSiteExperiencePromptBlock({
    intent: params.siteIntent,
    plan: params.homepagePlan,
    planIssues: params.homepagePlanIssues,
  });

  const aboveFoldStrategyBlock = buildAboveFoldStrategyPromptBlock({
    siteIntent: params.siteIntent,
    siteConfig: params.siteConfig,
    layoutOptions: params.layoutOptions,
    conflictsResolved: params.compositionConflictsResolved,
    conflictDecisions: params.compositionConflictDecisions,
  });

  return `=== UPGRADE — STUDIO COMPOSER (macro + sectie-archetypes) ===
**Belangrijk:** Secties die al in de bron-JSON staan: **html ongewijzigd** volgens upgrade-regels in §1.
Gebruik **compositionPlan** en \`_layout_archetypes\` hieronder om **nieuwe** secties vorm te geven en om te voorkomen dat elke run dezelfde generieke indeling kiest.

${experienceBlock}

${layoutBlock}

${aboveFoldStrategyBlock}

_component_variants (sectie-id → patroonnaam; voor nieuwe markup waar passend):
${JSON.stringify(params.components, null, 2)}
`;
}
