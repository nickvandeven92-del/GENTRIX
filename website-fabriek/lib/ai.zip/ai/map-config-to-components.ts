import type { SiteConfig } from "@/lib/ai/build-site-config";
import {
  buildStudioPromptLayoutMaps,
  type StudioPromptLayoutMapsOptions,
} from "@/lib/ai/studio-prompt-layout-maps";

/**
 * Mapt geplande sectie-id's naar benoemde layout-patronen voor de prompt (geen runtime components).
 * Synchroon met `mapConfigToLayoutArchetypes` — gebruik dezelfde `salt`, `themeMode` en optioneel `freeformSectionFraction`.
 */
export function mapConfigToComponents(
  config: SiteConfig,
  salt: string = "",
  options?: StudioPromptLayoutMapsOptions,
): Record<string, string> {
  return buildStudioPromptLayoutMaps(config, salt, options).components;
}
