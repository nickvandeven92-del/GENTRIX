/**
 * Anti-generieke copy-laag voor site-generatie.
 * Roteert schrijfmandates op basis van nonce + briefinglengte zodat zelfs korte input
 * minder “standaard AI-website” oplevert — zonder architectuur van de generator te breken.
 */

import type { DesignPersonality } from "@/lib/ai/design-personality";

function fnv1aHash(input: string): number {
  let h = 2166136261;
  for (let i = 0; i < input.length; i++) {
    h ^= input.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

/** Onder deze lengte (tekens, getrimd): extra instructies voor aanvullen zonder leugens. */
const THIN_BRIEF_THRESHOLD = 120;

const HERO_HOOK_MANDATES = [
  "Open de **hero-hoofdkop** met een **uitkomst of spanning** (wat de lezer wint of verliest), **niet** met een begroeting of bedrijfsnaam.",
  "Start met een **scherp contrast** (“Niet X, wel Y” / “Stop met …, begin met …”) — inhoudelijk passend bij de branche; geen lege slogans.",
  "Gebruik een **korte provocerende vraag** in de subkop of eyebrow (één zin), en beantwoord die met de hoofdkop + body.",
  "Leid met **één concreet scenario** (“Stel: je …”) dat herkenbaar is voor de doelgroep — geen generic “in deze tijd”.",
  "Maak de hero **cijfer- of feitelijk** in de subkop (range, tempo, scope) zonder valse precisie: gebruik “vaak”, “meestal”, “typisch” als de briefing geen harde data geeft.",
  "Kies een **tijd- of procesperspectief** (“Binnen …”, “In drie stappen”, “Van intake tot …”) als rode draad boven de fold.",
] as const;

const SECTION_VOICE_MANDATES = [
  "Features: beschrijf **gedrag en resultaat** per punt (wat verandert er voor de klant), niet alleen een productlabel + buzzword.",
  "Testimonials: minstens één citaat klinkt **menselijk** (kleine imperfectie, specifiek voordeel); verzin geen echte persoons- of bedrijfsnamen — gebruik functie + sector (“marketing lead, MKB-dienstverlener”).",
  "FAQ: stel **echte twijfels** (“Is dit geschikt als …?”, “Wat als …?”, “Hoe zit het met …?”) — verboden: alleen retorische “Wat doen jullie?”-vragen zonder scherpte.",
  "Pricing: noem **voor wie** elke tier bedoeld is in één zin; vermijd drie keer dezelfde openingszinstructuur per kaart.",
  "Footer: minstens **één** zin die **onderscheidend** is (aanpak, belofte, werkwijze) — niet alleen adres + links.",
] as const;

const CTA_DIVERSITY_MANDATES = [
  "Varieer **minstens drie** primaire CTA-teksten op de pagina (hero, mid-page, footer/pricing). Verboden als **dominante** CTA: “Klik hier”, “Meer informatie”, “Lees meer” (alleen secundair mag).",
  "Gebruik **werkwoord + object** (“Plan een kennismaking”, “Bekijk beschikbaarheid”, “Vraag offerte aan”) i.p.v. vage “Contact”.",
  "Koppel één CTA aan **tijd** (“Binnen 24 uur reactie”) alleen als dat geloofwaardig is voor de sector — anders neutrale actie.",
] as const;

const BANNED_COPY_PATTERNS = `
**Verboden woord-/zinsniveau (NL + doorslikte Anglicismen):**
- Openen met “Welkom bij …”, “Welkom op …”, “Hallo en welkom …” als **eerste** zin van de hero.
- Vage titels: “Over ons”, “Onze diensten”, “Kwaliteit staat centraal”, “Uw betrouwbare partner”, “Maatwerk voor elke klant”, “State of the art”, “Innovatieve oplossingen” **zonder** specifieke toelichting in dezelfde alinea.
- Triplets van lege bijvoeglijke naamwoorden (“betrouwbaar, professioneel en klantgericht”) zonder voorbeeld of bewijs in dezelfde sectie.
- Engelse filler in overwegend Nederlandse site: “We deliver excellence”, “Your success is our mission”, tenzij de briefing expliciet tweetalig vraagt.
`.trim();

const PERSONALITY_COPY_NUDGES: Record<DesignPersonality, string> = {
  bold_industrial: "Toon: **direct, kort, robuust** — weinig woorden, harde werkwoorden, geen marketingwas.",
  elegant_luxury: "Toon: **ingehouden, precies, rustig** — geen uitroeptekens-storm; prestige via keuze van woorden, niet via superlatieven.",
  playful_creative: "Toon: **warm, beeldend** — mag onverwacht, maar blijf volwassen; geen gimmick-copy in pricing/FAQ.",
  minimal_tech: "Toon: **knipperlicht-helder** — korte zinnen, weinig bijvoeglijke naamwoorden, functionele koppen.",
  editorial_art: "Toon: **magazine** — koppen met ritme, doorlopende leeslijn, ruimte voor nuance; geen corporate brochure-defaults.",
  trust_conversion: "Toon: **bewijs-gedreven** — cijfers, stappen, garanties waar logisch; geen holle “#1”-claims zonder onderbouwing in dezelfde sectie.",
};

export type AntiGenericCopyContext = {
  personality?: DesignPersonality;
  targetAudience?: string;
  primaryGoal?: string;
  brandStyle?: string;
};

export type BuildAntiGenericCopyPromptInput = {
  businessName: string;
  description: string;
  recentClientNames: string[];
  varianceNonce?: string;
} & AntiGenericCopyContext;

/**
 * Promptblok voor de user-prompt (Nederlands, strikt voor het model).
 */
export function buildAntiGenericCopyPromptBlock(input: BuildAntiGenericCopyPromptInput): string {
  const salt = `${input.businessName.trim()}\n${input.description.trim().slice(0, 200)}\n${input.recentClientNames.join(",")}\n${input.varianceNonce ?? ""}`;
  const h = fnv1aHash(salt);

  const heroMandate = HERO_HOOK_MANDATES[h % HERO_HOOK_MANDATES.length]!;
  const sectionMandate = SECTION_VOICE_MANDATES[(h >> 4) % SECTION_VOICE_MANDATES.length]!;
  const ctaMandate = CTA_DIVERSITY_MANDATES[(h >> 8) % CTA_DIVERSITY_MANDATES.length]!;

  const thinBrief = input.description.trim().length < THIN_BRIEF_THRESHOLD;

  const personalityLine =
    input.personality != null
      ? `- **Personality-copy:** ${PERSONALITY_COPY_NUDGES[input.personality]}`
      : "";

  const audienceLine =
    input.targetAudience?.trim()
      ? `- **Doelgroep uit config:** schrijf expliciet naar “${input.targetAudience.trim().replace(/"/g, "'").slice(0, 160)}” — vocabulaire en pijnpunten moeten daarop lijken.`
      : "";

  const goalLine =
    input.primaryGoal?.trim()
      ? `- **Conversiedoel:** ${input.primaryGoal.trim().replace(/_/g, " ")} — elke sectie moet dat doel **ondersteunen** (niet alleen “mooie tekst”).`
      : "";

  const styleLine =
    input.brandStyle?.trim()
      ? `- **Preset-stem:** \`brand_style\` = \`${input.brandStyle.trim().replace(/`/g, "'")}\` — laat woordkeuze en zinsritme aansluiten (strak/luxe/editorial/tech), nog steeds **zonder** standaard SaaS-clichés.`
      : "";

  const thinBriefBlock = thinBrief
    ? `
=== DUNNE BRIEFING — COPY AANVULLEN (geen valse claims) ===
De omschrijving van de klant is **kort of vaag**. Dat is geen excuus voor generieke teksten.

- **Vul strategisch aan** met plausibele, sector-passende taal (werkwoorden, situaties, deliverables).
- **Verzin niet:** echte klantnamen, awards, certificaten, jaartallen “sinds …”, omzet, medewerkersaantallen of reviews — tenzij ze in de briefing staan.
- **Mag wél:** typische werkwijze, voordelen, werkpakketten, “meestal”, “vaak”, “standaard inbegrepen” zolang het niet als hard feit wordt verkocht.
- Gebruik de **bedrijfsnaam** spaarzaam in de hero; focus op **lezer + probleem + uitkomst**.
`.trim()
    : "";

  const lines = [
    "=== ANTI-GENERIEKE COPY (verplicht) ===",
    "",
    "Elke site moet **inhoudelijk onderscheidend** aanvoelen — ook als de invoer dun is. Geen “standaard AI-landingspagina”-stem.",
    "",
    "**Mandates voor deze run (gekozen door systeem — volg ze):**",
    `- ${heroMandate}`,
    `- ${sectionMandate}`,
    `- ${ctaMandate}`,
    "",
    BANNED_COPY_PATTERNS,
    "",
    "**Differentie t.o.v. andere gegenereerde sites:** vermijd dezelfde openingszinstructuren en CTA-woorden als je zou kiezen voor een generieke B2B-template; laat **één** duidelijke “positioneringzin” ergens boven de fold (subkop of eyebrow) die je **niet** op elke willekeurige site zou plakken.",
    "",
    ...(personalityLine ? [personalityLine, ""] : []),
    ...(audienceLine ? [audienceLine, ""] : []),
    ...(goalLine ? [goalLine, ""] : []),
    ...(styleLine ? [styleLine, ""] : []),
  ];

  if (thinBriefBlock) {
    lines.push(thinBriefBlock, "");
  }

  return lines.join("\n").trim();
}
