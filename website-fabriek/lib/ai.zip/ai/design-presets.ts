/**
 * Design presets — puur visueel systeem (Tailwind-tokens voor `_design_preset`).
 * Geen verticale “voor tandartsen / voor SaaS”-labels: elke preset is een stijl die voor elke branche kan.
 * Businesscontext zit in copy, CTA’s en secties — niet in preset-id’s.
 *
 * **Editorial note:** `surfaces.card` blijft een geldige utility-string, maar prompts (zie
 * `premium-design-system-contract` + `layout-archetypes-prompt`) dwingen af dat modellen die
 * snippet **selectief** gebruiken — niet als standaard wrapper om elke kolom.
 */

// --- Types -------------------------------------------------------------------

export type ThemeMode = "light" | "dark" | "mixed";

export type AccentStrategy = "vibrant" | "subtle" | "monochrome" | "gradient";

export type ColorScale = {
  primary: string;
  secondary: string;
  accent: string;
  background: string;
  surface: string;
  surfaceAlt: string;
  text: string;
  textMuted: string;
  border: string;
  success?: string;
  warning?: string;
  danger?: string;
};

export type TypographyPreset = {
  heading: string;
  subheading: string;
  body: string;
  caption: string;
  eyebrow: string;
};

export type ButtonPreset = {
  primary: string;
  secondary: string;
  ghost: string;
  nav: string;
};

export type SurfacePreset = {
  page: string;
  section: string;
  sectionAlt: string;
  card: string;
  cardFeatured: string;
  input: string;
  badge: string;
  divider: string;
};

export type NavigationPreset = {
  wrapper: string;
  link: string;
  active: string;
  mobileMenu: string;
};

export type EffectsPreset = {
  shadow: string;
  shadowHeavy: string;
  gradient: string;
  glow: string;
  hover: string;
  transition: string;
  animation: string;
};

export type LayoutPreset = {
  container: string;
  containerWide: string;
  containerNarrow: string;
  sectionSpacing: string;
  sectionSpacingTight: string;
  sectionSpacingLoose: string;
  containerPadding: string;
  gridGap: string;
  radius: string;
};

export type SectionPreset = {
  hero: string;
  feature: string;
  featureGrid: string;
  testimonials: string;
  pricing: string;
  cta: string;
  footer: string;
};

export type DesignCategory =
  | "minimal"
  | "glass"
  | "bold"
  | "luxury"
  | "corporate"
  | "editorial"
  | "playful"
  | "dark"
  | "tech"
  | "organic"
  | "commerce";

/** Visuele metadata (geen brancheclaims). */
export type DesignPreset = {
  id: string;
  label: string;
  category: DesignCategory;
  themeMode: ThemeMode;
  accentStrategy: AccentStrategy;
  description: string;
  bestFor: string[];
  mood: string[];
  layout: LayoutPreset;
  typography: TypographyPreset;
  buttons: ButtonPreset;
  surfaces: SurfacePreset;
  navigation: NavigationPreset;
  effects: EffectsPreset;
  sections: SectionPreset;
  colors: ColorScale;
};

// --- Shared section grids ----------------------------------------------------

const sectionsStandard = {
  hero: "relative overflow-hidden",
  feature: "relative",
  featureGrid: "grid md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8",
  testimonials: "grid md:grid-cols-2 lg:grid-cols-3 gap-6",
  pricing: "grid lg:grid-cols-3 gap-6 lg:gap-8 items-stretch",
  cta: "relative rounded-3xl border border-gray-200 bg-gradient-to-br from-white to-gray-50 p-8 md:p-12",
  footer: "border-t border-gray-200 bg-white",
} satisfies SectionPreset;

const preset_minimal_dark: DesignPreset = {
  id: "minimal_dark",
  label: "Minimal Dark",
  category: "dark",
  themeMode: "dark",
  accentStrategy: "vibrant",
  description: "Donker canvas, blauwe accenten, hoog contrast. Tijdloos en professioneel.",
  bestFor: ["Dark UI", "High contrast", "Dashboard-style landings"],
  mood: ["Strak", "Modern", "Contrast"],
  layout: {
    container: "max-w-7xl mx-auto px-6 py-24",
    containerWide: "max-w-[90rem] mx-auto px-6 lg:px-10",
    containerNarrow: "max-w-4xl mx-auto px-6",
    sectionSpacing: "py-24",
    sectionSpacingTight: "py-16 md:py-20",
    sectionSpacingLoose: "py-28 md:py-36",
    containerPadding: "px-6",
    gridGap: "gap-8 lg:gap-10",
    radius: "rounded-xl",
  },
  typography: {
    heading: "text-5xl md:text-6xl font-bold text-white tracking-tight",
    subheading: "text-lg text-gray-400 max-w-2xl",
    body: "text-base md:text-lg text-gray-300 leading-relaxed",
    caption: "text-sm uppercase tracking-wider text-gray-500",
    eyebrow: "text-sm font-semibold uppercase tracking-[0.15em] text-blue-400",
  },
  buttons: {
    primary:
      "inline-flex items-center justify-center bg-blue-500 hover:bg-blue-600 text-white px-6 py-3 rounded-xl transition shadow-lg shadow-blue-500/25 font-semibold",
    secondary:
      "inline-flex items-center justify-center border border-gray-600 hover:border-gray-500 text-white px-6 py-3 rounded-xl transition bg-transparent font-medium",
    ghost:
      "inline-flex items-center justify-center text-gray-400 hover:text-white px-5 py-2.5 rounded-xl transition font-medium",
    nav: "inline-flex items-center justify-center bg-blue-600 hover:bg-blue-500 text-white px-4 py-2 rounded-lg text-sm font-medium",
  },
  surfaces: {
    page: "bg-gray-950",
    section: "bg-transparent",
    sectionAlt: "bg-gray-900/40",
    card: "bg-gray-900/60 border border-gray-800 rounded-xl shadow-xl",
    cardFeatured: "bg-gray-900 border border-blue-500/25 rounded-xl shadow-2xl",
    input:
      "w-full px-4 py-3 bg-gray-900 border border-gray-700 rounded-xl text-white placeholder-gray-500 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 outline-none",
    badge: "inline-flex items-center px-3 py-1 bg-gray-800 text-gray-300 text-xs rounded-full",
    divider: "border-t border-gray-800",
  },
  navigation: {
    wrapper: "bg-gray-950/90 backdrop-blur-md border-b border-gray-800 sticky top-0 z-50",
    link: "text-gray-400 hover:text-white transition-colors duration-200 font-medium",
    active: "text-white border-b-2 border-blue-500",
    mobileMenu: "bg-gray-950/95 backdrop-blur-md border border-gray-800 rounded-xl shadow-xl",
  },
  effects: {
    shadow: "shadow-xl shadow-black/30",
    shadowHeavy: "shadow-2xl shadow-black/50",
    gradient: "bg-gradient-to-b from-gray-950 via-gray-900 to-gray-950",
    glow: "shadow-[0_0_60px_-15px_rgba(59,130,246,0.35)]",
    hover: "hover:-translate-y-0.5",
    transition: "transition-all duration-300",
    animation: "duration-300 ease-out",
  },
  sections: {
    ...sectionsStandard,
    cta: "relative rounded-2xl border border-gray-800 bg-gray-900/80 p-8 md:p-12",
    footer: "border-t border-gray-800 bg-gray-950",
  },
  colors: {
    primary: "#3B82F6",
    secondary: "#1D4ED8",
    accent: "#60A5FA",
    background: "#0B0B0B",
    surface: "#111827",
    surfaceAlt: "#1F2937",
    text: "#F9FAFB",
    textMuted: "#9CA3AF",
    border: "#374151",
    success: "#22C55E",
    warning: "#F59E0B",
    danger: "#EF4444",
  },
};

const preset_minimal_light: DesignPreset = {
  id: "minimal_light",
  label: "Minimal Light",
  category: "minimal",
  themeMode: "light",
  accentStrategy: "vibrant",
  description: "Clean, veel witruimte, focus op typografie en inhoud.",
  bestFor: ["Lichte interfaces", "Documentatie-stijl", "Rustige landings"],
  mood: ["Clean", "Rust", "Leesbaar"],
  layout: {
    container: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
    containerWide: "max-w-[90rem] mx-auto px-4 sm:px-6 lg:px-8",
    containerNarrow: "max-w-3xl mx-auto px-4 sm:px-6 lg:px-8",
    sectionSpacing: "py-16 md:py-24",
    sectionSpacingTight: "py-12 md:py-16",
    sectionSpacingLoose: "py-24 md:py-32",
    containerPadding: "px-4 sm:px-6 lg:px-8",
    gridGap: "gap-6 lg:gap-8",
    radius: "rounded-xl",
  },
  typography: {
    heading: "font-sans text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight text-gray-900",
    subheading: "text-lg md:text-xl text-gray-600 max-w-2xl",
    body: "text-base md:text-lg text-gray-700 leading-relaxed",
    caption: "text-sm text-gray-500",
    eyebrow: "text-sm font-semibold uppercase tracking-wide text-gray-500",
  },
  buttons: {
    primary:
      "inline-flex items-center justify-center bg-gray-900 hover:bg-gray-800 text-white px-6 py-3 rounded-xl transition-all font-medium",
    secondary:
      "inline-flex items-center justify-center border border-gray-300 hover:border-gray-400 text-gray-700 px-6 py-3 rounded-xl transition-all",
    ghost:
      "inline-flex items-center justify-center text-gray-600 hover:text-gray-900 px-5 py-2.5 rounded-xl transition-all",
    nav: "inline-flex items-center justify-center bg-gray-900 text-white px-4 py-2 rounded-lg text-sm font-medium",
  },
  surfaces: {
    page: "bg-white",
    section: "bg-white",
    sectionAlt: "bg-gray-50",
    card: "bg-white border border-gray-100 rounded-xl shadow-sm hover:shadow-md transition-all",
    cardFeatured: "bg-white border border-gray-200 rounded-xl shadow-lg",
    input:
      "w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:border-gray-400 focus:ring-1 focus:ring-gray-400 outline-none",
    badge: "inline-flex items-center px-3 py-1 bg-gray-100 text-gray-700 text-xs rounded-full",
    divider: "border-t border-gray-100",
  },
  navigation: {
    wrapper: "bg-white/80 backdrop-blur-sm border-b border-gray-100 sticky top-0 z-50",
    link: "text-gray-600 hover:text-gray-900 transition-colors",
    active: "text-gray-900 font-semibold",
    mobileMenu: "bg-white border border-gray-100 rounded-xl shadow-lg",
  },
  effects: {
    shadow: "shadow-lg shadow-gray-900/5",
    shadowHeavy: "shadow-xl shadow-gray-900/10",
    gradient: "bg-gradient-to-b from-white to-gray-50",
    glow: "",
    hover: "hover:-translate-y-0.5",
    transition: "transition-all duration-200",
    animation: "duration-300 ease-out",
  },
  sections: { ...sectionsStandard },
  colors: {
    primary: "#111827",
    secondary: "#374151",
    accent: "#3B82F6",
    background: "#FFFFFF",
    surface: "#F9FAFB",
    surfaceAlt: "#F3F4F6",
    text: "#111827",
    textMuted: "#6B7280",
    border: "#E5E7EB",
    success: "#10B981",
    warning: "#F59E0B",
    danger: "#EF4444",
  },
};

const preset_glass: DesignPreset = {
  id: "glass",
  label: "Glassmorphism",
  category: "glass",
  themeMode: "dark",
  accentStrategy: "gradient",
  description: "Glas, diepte, transparantie — premium donkere esthetiek.",
  bestFor: ["Glaseffecten", "Donkere hero’s", "Gradient accenten"],
  mood: ["Diepte", "Futuristisch", "Premium"],
  layout: {
    container: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
    containerWide: "max-w-[92rem] mx-auto px-4 sm:px-6 lg:px-8",
    containerNarrow: "max-w-4xl mx-auto px-4 sm:px-6 lg:px-8",
    sectionSpacing: "py-20 md:py-28",
    sectionSpacingTight: "py-12 md:py-16",
    sectionSpacingLoose: "py-24 md:py-32 lg:py-40",
    containerPadding: "px-4 sm:px-6 lg:px-8",
    gridGap: "gap-6 lg:gap-8",
    radius: "rounded-2xl",
  },
  typography: {
    heading:
      "font-sans text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-semibold tracking-tight bg-gradient-to-r from-white via-white to-gray-300 bg-clip-text text-transparent",
    subheading: "text-lg md:text-xl text-white/80 font-light max-w-2xl",
    body: "text-base text-white/70 leading-relaxed",
    caption: "text-sm text-white/50 uppercase tracking-wider",
    eyebrow: "text-sm font-semibold uppercase tracking-[0.18em] text-fuchsia-300",
  },
  buttons: {
    primary:
      "inline-flex items-center justify-center bg-white/10 backdrop-blur-md hover:bg-white/20 text-white px-7 md:px-8 py-3.5 md:py-4 rounded-2xl transition-all duration-300 font-medium border border-white/20 shadow-xl hover:shadow-2xl hover:-translate-y-1",
    secondary:
      "inline-flex items-center justify-center bg-white hover:bg-gray-100 text-gray-900 px-7 md:px-8 py-3.5 md:py-4 rounded-2xl transition-all duration-300 font-medium shadow-xl",
    ghost:
      "inline-flex items-center justify-center text-white/80 hover:text-white hover:bg-white/10 px-5 md:px-6 py-2.5 rounded-2xl transition-all duration-300",
    nav: "inline-flex items-center justify-center bg-white text-gray-900 hover:bg-gray-100 px-4 md:px-5 py-2 rounded-xl transition-all duration-200 font-medium text-sm",
  },
  surfaces: {
    page: "bg-[#0F0F0F]",
    section: "bg-transparent",
    sectionAlt: "bg-white/[0.03]",
    card: "bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl shadow-2xl transition-all duration-500 hover:bg-white/15",
    cardFeatured: "bg-white/15 backdrop-blur-2xl border border-white/25 rounded-3xl shadow-2xl",
    input:
      "w-full px-4 py-3 bg-white/10 backdrop-blur-md border border-white/20 rounded-xl focus:border-white/40 focus:ring-2 focus:ring-white/20 outline-none transition text-white placeholder-white/50",
    badge: "inline-flex items-center px-3 py-1 bg-white/20 backdrop-blur-sm text-white text-xs rounded-full",
    divider: "border-t border-white/10",
  },
  navigation: {
    wrapper: "bg-black/30 backdrop-blur-2xl border-b border-white/10 sticky top-0 z-50",
    link: "text-white/70 hover:text-white transition-colors duration-200",
    active: "text-white font-semibold",
    mobileMenu: "bg-black/80 backdrop-blur-2xl border border-white/10 rounded-2xl",
  },
  effects: {
    shadow: "shadow-2xl shadow-black/20",
    shadowHeavy: "shadow-[0_40px_120px_-30px_rgba(0,0,0,0.55)]",
    gradient: "bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900",
    glow: "shadow-[0_0_140px_-30px_rgba(168,85,247,0.45)]",
    hover: "hover:-translate-y-1",
    transition: "transition-all duration-500",
    animation: "duration-500 ease-out",
  },
  sections: {
    ...sectionsStandard,
    cta: "relative rounded-3xl border border-white/15 bg-white/10 backdrop-blur-2xl p-8 md:p-12",
    footer: "border-t border-white/10 bg-black/20",
  },
  colors: {
    primary: "#FFFFFF",
    secondary: "#A855F7",
    accent: "#EC4899",
    background: "#0F0F0F",
    surface: "#1A1A1A",
    surfaceAlt: "#232326",
    text: "#FFFFFF",
    textMuted: "#A1A1AA",
    border: "rgba(255,255,255,0.12)",
    success: "#22C55E",
    warning: "#F59E0B",
    danger: "#F87171",
  },
};

const preset_luxury: DesignPreset = {
  id: "luxury",
  label: "Luxury",
  category: "luxury",
  themeMode: "light",
  accentStrategy: "subtle",
  description: "Elegant, serif koppen, gouden accenten, tijdloos.",
  bestFor: ["Serif koppen", "Veel witruimte", "Subtiele luxe"],
  mood: ["Tijdloos", "Refined", "Rustig"],
  layout: {
    container: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
    containerWide: "max-w-[90rem] mx-auto px-4 sm:px-6 lg:px-8",
    containerNarrow: "max-w-4xl mx-auto px-4 sm:px-6 lg:px-8",
    sectionSpacing: "py-20 md:py-28 lg:py-36",
    sectionSpacingTight: "py-12 md:py-16 lg:py-20",
    sectionSpacingLoose: "py-28 md:py-36 lg:py-44",
    containerPadding: "px-4 sm:px-6 lg:px-8",
    gridGap: "gap-8 lg:gap-12",
    radius: "rounded-none",
  },
  typography: {
    heading:
      "font-serif text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-light tracking-tight text-gray-900",
    subheading:
      "font-serif text-xl md:text-2xl text-gray-600 font-light leading-relaxed max-w-2xl",
    body: "font-sans text-base md:text-lg text-gray-700 leading-relaxed",
    caption: "font-sans text-sm uppercase tracking-[0.2em] text-gray-500",
    eyebrow: "font-sans text-xs uppercase tracking-[0.2em] text-gray-400",
  },
  buttons: {
    primary:
      "inline-flex items-center justify-center bg-gray-900 hover:bg-gray-800 text-white px-8 md:px-10 py-3.5 md:py-4 rounded-none transition-all duration-500 font-light tracking-wide shadow-xl hover:shadow-2xl hover:-translate-y-0.5",
    secondary:
      "inline-flex items-center justify-center border border-gray-900 hover:bg-gray-900 hover:text-white text-gray-900 px-8 md:px-10 py-3.5 md:py-4 rounded-none transition-all duration-500 font-light tracking-wide",
    ghost:
      "inline-flex items-center justify-center text-gray-600 hover:text-gray-900 px-6 md:px-8 py-3 rounded-none transition-all duration-500",
    nav: "inline-flex items-center justify-center bg-gray-900 text-white px-5 md:px-6 py-2.5 rounded-none transition-all duration-500 font-light text-sm",
  },
  surfaces: {
    page: "bg-white",
    section: "bg-white",
    sectionAlt: "bg-gray-50",
    card: "bg-white border border-gray-100 p-6 md:p-8 hover:shadow-2xl transition-all duration-700",
    cardFeatured: "bg-white border-2 border-gray-200 p-8 md:p-10 shadow-2xl",
    input:
      "w-full px-0 py-3 border-b-2 border-gray-200 focus:border-gray-900 outline-none transition-colors bg-transparent text-gray-900",
    badge: "inline-flex items-center px-4 py-1 bg-gray-100 text-gray-600 text-xs tracking-wide",
    divider: "border-t border-gray-100",
  },
  navigation: {
    wrapper: "bg-white/95 backdrop-blur-sm border-b border-gray-100 sticky top-0 z-50",
    link: "text-gray-600 hover:text-gray-900 transition-colors duration-300 font-light",
    active: "text-gray-900 border-b border-gray-900",
    mobileMenu: "bg-white/95 backdrop-blur-md border border-gray-100",
  },
  effects: {
    shadow: "shadow-xl shadow-gray-900/5",
    shadowHeavy: "shadow-2xl shadow-gray-900/10",
    gradient: "bg-gradient-to-b from-white to-gray-50",
    glow: "",
    hover: "hover:-translate-y-0.5",
    transition: "transition-all duration-700",
    animation: "duration-700 ease-out",
  },
  sections: {
    ...sectionsStandard,
    cta: "relative border border-gray-100 bg-gray-50 p-10 md:p-16",
    footer: "border-t border-gray-100 bg-white",
  },
  colors: {
    primary: "#111111",
    secondary: "#333333",
    accent: "#D4AF37",
    background: "#FFFFFF",
    surface: "#F8F8F8",
    surfaceAlt: "#F5F5F5",
    text: "#111111",
    textMuted: "#666666",
    border: "#E5E5E5",
    success: "#059669",
    warning: "#D97706",
    danger: "#DC2626",
  },
};

const preset_corporate: DesignPreset = {
  id: "corporate",
  label: "Corporate",
  category: "corporate",
  themeMode: "light",
  accentStrategy: "vibrant",
  description: "Strak, betrouwbaar, formeel — blauw en neutraal.",
  bestFor: ["Formele landings", "Dichte informatie", "Tabellen en cards"],
  mood: ["Betrouwbaar", "Strak", "Zakelijk"],
  layout: {
    container: "max-w-6xl mx-auto px-4 sm:px-6 lg:px-8",
    containerWide: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
    containerNarrow: "max-w-4xl mx-auto px-4 sm:px-6 lg:px-8",
    sectionSpacing: "py-16 md:py-20 lg:py-24",
    sectionSpacingTight: "py-10 md:py-14 lg:py-16",
    sectionSpacingLoose: "py-20 md:py-28 lg:py-36",
    containerPadding: "px-4 sm:px-6 lg:px-8",
    gridGap: "gap-5 lg:gap-6",
    radius: "rounded-lg",
  },
  typography: {
    heading:
      "font-sans text-3xl md:text-4xl lg:text-5xl xl:text-6xl font-bold text-gray-900 tracking-tight",
    subheading: "text-lg md:text-xl text-gray-600 font-normal max-w-3xl",
    body: "text-base text-gray-700 leading-relaxed",
    caption: "text-sm text-gray-500 uppercase tracking-wide",
    eyebrow: "text-sm font-semibold uppercase tracking-[0.16em] text-blue-700",
  },
  buttons: {
    primary:
      "inline-flex items-center justify-center bg-blue-700 hover:bg-blue-800 text-white px-5 md:px-6 py-2.5 md:py-3 rounded-lg transition-all duration-200 font-semibold shadow-md hover:shadow-lg",
    secondary:
      "inline-flex items-center justify-center border border-gray-300 hover:border-gray-400 hover:bg-gray-50 text-gray-700 px-5 md:px-6 py-2.5 md:py-3 rounded-lg transition-all duration-200 font-semibold",
    ghost:
      "inline-flex items-center justify-center text-gray-700 hover:text-blue-700 hover:bg-gray-50 px-4 md:px-5 py-2 rounded-lg transition-all duration-200",
    nav: "inline-flex items-center justify-center bg-blue-700 hover:bg-blue-800 text-white px-4 md:px-5 py-2 rounded-lg transition-all duration-200 font-semibold text-sm",
  },
  surfaces: {
    page: "bg-white",
    section: "bg-white",
    sectionAlt: "bg-gray-50",
    card: "bg-white border border-gray-200 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-200",
    cardFeatured: "bg-white border-2 border-blue-200 rounded-xl shadow-lg",
    input:
      "w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition",
    badge: "inline-flex items-center px-2.5 py-0.5 bg-gray-100 text-gray-700 text-xs font-medium rounded",
    divider: "border-t border-gray-200",
  },
  navigation: {
    wrapper: "bg-white border-b border-gray-200 sticky top-0 z-50",
    link: "text-gray-700 hover:text-blue-700 transition-colors duration-200",
    active: "text-blue-700 font-semibold",
    mobileMenu: "bg-white shadow-lg border border-gray-200 rounded-xl",
  },
  effects: {
    shadow: "shadow-lg shadow-gray-200/50",
    shadowHeavy: "shadow-[0_24px_60px_-24px_rgba(0,0,0,0.18)]",
    gradient: "bg-gradient-to-b from-white to-gray-50",
    glow: "",
    hover: "hover:-translate-y-0.5",
    transition: "transition-all duration-200",
    animation: "duration-200 ease-linear",
  },
  sections: {
    hero: "relative",
    feature: "relative",
    featureGrid: "grid md:grid-cols-2 lg:grid-cols-3 gap-5 lg:gap-6",
    testimonials: "grid md:grid-cols-2 gap-6",
    pricing: "grid lg:grid-cols-3 gap-6 items-stretch",
    cta: "rounded-2xl border border-gray-200 bg-white p-8 md:p-10 shadow-md",
    footer: "border-t border-gray-200 bg-gray-50",
  },
  colors: {
    primary: "#1E40AF",
    secondary: "#3B82F6",
    accent: "#F59E0B",
    background: "#FFFFFF",
    surface: "#F3F4F6",
    surfaceAlt: "#E5E7EB",
    text: "#111827",
    textMuted: "#6B7280",
    border: "#D1D5DB",
    success: "#15803D",
    warning: "#D97706",
    danger: "#DC2626",
  },
};

const preset_editorial: DesignPreset = {
  id: "editorial",
  label: "Editorial",
  category: "editorial",
  themeMode: "light",
  accentStrategy: "subtle",
  description: "Magazine-stijl, serif, rustige kolommen, hoge leesbaarheid.",
  bestFor: ["Lange teksten", "Magazine-layouts", "Kolom-grid"],
  mood: ["Leesbaar", "Authentiek", "Rust"],
  layout: {
    container: "max-w-5xl mx-auto px-4 sm:px-6 lg:px-8",
    containerWide: "max-w-6xl mx-auto px-4 sm:px-6 lg:px-8",
    containerNarrow: "max-w-3xl mx-auto px-4 sm:px-6",
    sectionSpacing: "py-16 md:py-24 lg:py-28",
    sectionSpacingTight: "py-10 md:py-14",
    sectionSpacingLoose: "py-20 md:py-32",
    containerPadding: "px-4 sm:px-6 lg:px-8",
    gridGap: "gap-8 lg:gap-10",
    radius: "rounded-sm",
  },
  typography: {
    heading:
      "font-serif text-4xl md:text-5xl lg:text-6xl font-medium text-gray-900 tracking-tight leading-tight",
    subheading: "font-serif text-xl md:text-2xl text-gray-600 leading-relaxed max-w-2xl",
    body: "font-serif text-lg text-gray-700 leading-relaxed",
    caption: "text-xs uppercase tracking-[0.2em] text-gray-500 font-sans",
    eyebrow: "text-xs font-sans font-semibold uppercase tracking-[0.2em] text-gray-500",
  },
  buttons: {
    primary:
      "inline-flex items-center justify-center bg-gray-900 hover:bg-black text-white px-6 py-3 rounded-sm font-medium tracking-wide transition-colors",
    secondary:
      "inline-flex items-center justify-center border border-gray-900 text-gray-900 hover:bg-gray-900 hover:text-white px-6 py-3 rounded-sm font-medium transition-colors",
    ghost:
      "inline-flex items-center justify-center text-gray-700 hover:text-gray-900 underline-offset-4 hover:underline px-4 py-2",
    nav: "inline-flex items-center justify-center text-gray-900 border border-gray-300 hover:border-gray-900 px-4 py-2 text-sm rounded-sm",
  },
  surfaces: {
    page: "bg-[#FDFCF8]",
    section: "bg-transparent",
    sectionAlt: "bg-white",
    card: "bg-white border border-gray-200 p-6 md:p-8 shadow-sm",
    cardFeatured: "bg-gray-900 text-[#FDFCF8] p-8 md:p-10",
    input:
      "w-full px-4 py-3 border border-gray-300 rounded-sm focus:border-gray-900 outline-none bg-white",
    badge:
      "inline-flex items-center px-2 py-0.5 border border-gray-400 text-gray-700 text-xs uppercase tracking-wider",
    divider: "border-t border-gray-200",
  },
  navigation: {
    wrapper: "bg-[#FDFCF8]/95 border-b border-gray-200 sticky top-0 z-50",
    link: "text-gray-700 hover:text-gray-900 font-medium text-sm",
    active: "text-gray-900 underline decoration-1 underline-offset-8",
    mobileMenu: "bg-white border border-gray-200 rounded-sm shadow-lg",
  },
  effects: {
    shadow: "shadow-sm shadow-gray-900/5",
    shadowHeavy: "shadow-md shadow-gray-900/10",
    gradient: "bg-gradient-to-b from-[#FDFCF8] to-white",
    glow: "",
    hover: "hover:opacity-90",
    transition: "transition-all duration-200",
    animation: "duration-300 ease-out",
  },
  sections: {
    hero: "relative",
    feature: "relative",
    featureGrid: "grid md:grid-cols-2 gap-8 lg:gap-12",
    testimonials: "grid md:grid-cols-2 gap-8",
    pricing: "grid lg:grid-cols-3 gap-6 items-stretch",
    cta: "border border-gray-200 bg-white p-8 md:p-12",
    footer: "border-t border-gray-200 bg-[#FDFCF8]",
  },
  colors: {
    primary: "#1C1917",
    secondary: "#44403C",
    accent: "#B45309",
    background: "#FDFCF8",
    surface: "#FFFFFF",
    surfaceAlt: "#F5F5F4",
    text: "#1C1917",
    textMuted: "#78716C",
    border: "#E7E5E4",
    success: "#15803D",
    warning: "#CA8A04",
    danger: "#B91C1C",
  },
};

const preset_playful: DesignPreset = {
  id: "playful",
  label: "Playful",
  category: "playful",
  themeMode: "light",
  accentStrategy: "gradient",
  description: "Gradientkoppen, ronde vormen, expressieve accenten.",
  bestFor: ["Kleurrijke hero’s", "Gradient UI", "Sterke visuele hiërarchie"],
  mood: ["Expressief", "Energiek", "Bold"],
  layout: {
    container: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
    containerWide: "max-w-[85rem] mx-auto px-4 sm:px-6 lg:px-8",
    containerNarrow: "max-w-3xl mx-auto px-4 sm:px-6 lg:px-8",
    sectionSpacing: "py-16 md:py-24",
    sectionSpacingTight: "py-10 md:py-14",
    sectionSpacingLoose: "py-24 md:py-32",
    containerPadding: "px-4 sm:px-6 lg:px-8",
    gridGap: "gap-6 lg:gap-8",
    radius: "rounded-3xl",
  },
  typography: {
    heading:
      "font-sans text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-black tracking-tighter bg-gradient-to-r from-purple-600 via-pink-600 to-orange-600 bg-clip-text text-transparent",
    subheading: "text-xl md:text-2xl text-gray-700 font-medium max-w-2xl",
    body: "text-base md:text-lg text-gray-600 leading-relaxed",
    caption: "text-sm font-mono text-gray-500",
    eyebrow: "text-sm font-bold uppercase tracking-[0.1em] text-purple-600",
  },
  buttons: {
    primary:
      "inline-flex items-center justify-center bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-6 md:px-8 py-3 md:py-4 rounded-full transition-all duration-300 font-bold shadow-lg hover:shadow-xl hover:-translate-y-1",
    secondary:
      "inline-flex items-center justify-center border-2 border-purple-600 hover:bg-purple-600 hover:text-white text-purple-600 px-6 md:px-8 py-3 md:py-4 rounded-full transition-all duration-300 font-bold",
    ghost:
      "inline-flex items-center justify-center text-gray-700 hover:text-purple-600 px-5 md:px-6 py-2.5 rounded-full transition-all duration-300 font-medium",
    nav: "inline-flex items-center justify-center bg-black hover:bg-gray-900 text-white px-4 md:px-5 py-2 rounded-full transition-all duration-200 font-medium text-sm",
  },
  surfaces: {
    page: "bg-white",
    section: "bg-white",
    sectionAlt: "bg-gradient-to-br from-purple-50/50 via-white to-pink-50/50",
    card: "bg-white border border-gray-100 rounded-3xl shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2",
    cardFeatured: "bg-gradient-to-br from-purple-50 to-pink-50 border border-purple-100 rounded-3xl shadow-xl",
    input:
      "w-full px-4 py-3 bg-gray-50 border-2 border-gray-200 rounded-2xl focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 outline-none transition-all",
    badge: "inline-flex items-center px-3 py-1 bg-purple-100 text-purple-700 text-xs font-bold rounded-full",
    divider: "border-t border-gray-100",
  },
  navigation: {
    wrapper: "bg-white/80 backdrop-blur-lg border-b border-gray-100 sticky top-0 z-50",
    link: "text-gray-600 hover:text-purple-600 transition-colors duration-200 font-medium",
    active: "text-purple-600 font-bold",
    mobileMenu: "bg-white/95 backdrop-blur-xl border border-gray-100 rounded-2xl shadow-xl",
  },
  effects: {
    shadow: "shadow-2xl shadow-gray-900/5",
    shadowHeavy: "shadow-[0_30px_80px_-20px_rgba(168,85,247,0.25)]",
    gradient: "bg-gradient-to-br from-purple-50 via-white to-pink-50",
    glow: "shadow-[0_0_100px_-20px_rgba(168,85,247,0.35)]",
    hover: "hover:-translate-y-2 hover:scale-[1.02]",
    transition: "transition-all duration-300",
    animation: "duration-300 ease-out",
  },
  sections: {
    ...sectionsStandard,
    cta: "relative rounded-3xl bg-gradient-to-r from-purple-600 to-pink-600 p-8 md:p-14 text-white",
    footer: "border-t border-gray-100 bg-gray-50",
  },
  colors: {
    primary: "#8B5CF6",
    secondary: "#EC4899",
    accent: "#F97316",
    background: "#FFFFFF",
    surface: "#FAFAFA",
    surfaceAlt: "#F5F3FF",
    text: "#1F2937",
    textMuted: "#6B7280",
    border: "#E5E7EB",
    success: "#10B981",
    warning: "#F59E0B",
    danger: "#EF4444",
  },
};

const preset_tech_saas: DesignPreset = {
  id: "tech_saas",
  label: "Tech / SaaS",
  category: "tech",
  themeMode: "light",
  accentStrategy: "gradient",
  description: "Licht canvas, blauw–indigo gradient, strakke cards — product-landing.",
  bestFor: ["Product landings", "Feature-grids", "Gradient headings"],
  mood: ["Modern", "Trust", "Snel"],
  layout: {
    container: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
    containerWide: "max-w-[90rem] mx-auto px-4 sm:px-6 lg:px-8",
    containerNarrow: "max-w-4xl mx-auto px-4 sm:px-6 lg:px-8",
    sectionSpacing: "py-16 md:py-24 lg:py-32",
    sectionSpacingTight: "py-12 md:py-16 lg:py-20",
    sectionSpacingLoose: "py-24 md:py-32 lg:py-40",
    containerPadding: "px-4 sm:px-6 lg:px-8",
    gridGap: "gap-6 lg:gap-8",
    radius: "rounded-2xl",
  },
  typography: {
    heading:
      "font-sans text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-bold tracking-tight bg-gradient-to-r from-gray-900 via-gray-800 to-gray-900 bg-clip-text text-transparent",
    subheading: "text-lg md:text-xl text-gray-600 font-normal leading-relaxed max-w-2xl",
    body: "text-base md:text-lg text-gray-700 leading-relaxed",
    caption: "text-sm font-mono text-gray-500",
    eyebrow: "text-sm font-semibold uppercase tracking-[0.18em] text-blue-600",
  },
  buttons: {
    primary:
      "inline-flex items-center justify-center bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white px-6 md:px-7 py-3 rounded-xl transition-all duration-200 font-semibold shadow-lg shadow-blue-500/25 hover:shadow-xl hover:-translate-y-0.5",
    secondary:
      "inline-flex items-center justify-center bg-gray-100 hover:bg-gray-200 text-gray-900 px-6 md:px-7 py-3 rounded-xl transition-all duration-200 font-semibold",
    ghost:
      "inline-flex items-center justify-center text-gray-700 hover:text-gray-900 hover:bg-gray-100 px-5 md:px-6 py-2.5 rounded-xl transition-all duration-200 font-medium",
    nav: "inline-flex items-center justify-center bg-gray-900 hover:bg-black text-white px-4 md:px-5 py-2 rounded-xl transition-all duration-200 font-medium text-sm",
  },
  surfaces: {
    page: "bg-white",
    section: "bg-white",
    sectionAlt: "bg-gray-50/70",
    card: "bg-white border border-gray-100 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300",
    cardFeatured: "bg-gradient-to-b from-white to-blue-50/40 border border-blue-100 rounded-2xl shadow-xl",
    input:
      "w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 outline-none transition-all",
    badge: "inline-flex items-center px-3 py-1 bg-blue-50 text-blue-700 text-xs font-semibold rounded-full",
    divider: "border-t border-gray-200",
  },
  navigation: {
    wrapper: "bg-white/80 backdrop-blur-lg border-b border-gray-200/80 sticky top-0 z-50",
    link: "text-gray-600 hover:text-gray-900 transition-colors duration-200 font-medium",
    active: "text-blue-600 font-semibold",
    mobileMenu: "bg-white/90 backdrop-blur-lg border border-gray-200 rounded-2xl shadow-xl",
  },
  effects: {
    shadow: "shadow-2xl shadow-gray-900/5",
    shadowHeavy: "shadow-[0_30px_80px_-20px_rgba(0,0,0,0.18)]",
    gradient: "bg-gradient-to-br from-white via-gray-50 to-white",
    glow: "ring-1 ring-blue-500/10 shadow-[0_0_120px_-20px_rgba(59,130,246,0.25)]",
    hover: "hover:scale-[1.02]",
    transition: "transition-all duration-300",
    animation: "duration-300 ease-in-out",
  },
  sections: { ...sectionsStandard },
  colors: {
    primary: "#2563EB",
    secondary: "#4F46E5",
    accent: "#06B6D4",
    background: "#FFFFFF",
    surface: "#F9FAFB",
    surfaceAlt: "#F3F4F6",
    text: "#111827",
    textMuted: "#6B7280",
    border: "#E5E7EB",
    success: "#16A34A",
    warning: "#F59E0B",
    danger: "#DC2626",
  },
};

const preset_organic_soft: DesignPreset = {
  id: "organic_soft",
  label: "Organic Soft",
  category: "organic",
  themeMode: "light",
  accentStrategy: "subtle",
  description: "Zachte teal, rustige surfaces, vriendelijke rondingen.",
  bestFor: ["Zachte paletten", "Rustige flows", "Natuurlijke tinten"],
  mood: ["Rust", "Zacht", "Open"],
  layout: {
    container: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
    containerWide: "max-w-[88rem] mx-auto px-4 sm:px-6 lg:px-8",
    containerNarrow: "max-w-4xl mx-auto px-4 sm:px-6 lg:px-8",
    sectionSpacing: "py-14 md:py-20 lg:py-24",
    sectionSpacingTight: "py-10 md:py-14",
    sectionSpacingLoose: "py-20 md:py-28 lg:py-32",
    containerPadding: "px-4 sm:px-6 lg:px-8",
    gridGap: "gap-6 lg:gap-7",
    radius: "rounded-2xl",
  },
  typography: {
    heading: "font-sans text-3xl md:text-4xl lg:text-5xl xl:text-6xl font-bold tracking-tight text-gray-900",
    subheading: "text-lg md:text-xl text-gray-600 font-normal max-w-2xl",
    body: "text-base md:text-lg text-gray-700 leading-relaxed",
    caption: "text-sm text-gray-500",
    eyebrow: "text-sm font-semibold uppercase tracking-[0.15em] text-teal-600",
  },
  buttons: {
    primary:
      "inline-flex items-center justify-center bg-teal-600 hover:bg-teal-700 text-white px-6 md:px-7 py-3 rounded-2xl transition-all duration-200 font-semibold shadow-md hover:shadow-lg hover:-translate-y-0.5",
    secondary:
      "inline-flex items-center justify-center border border-teal-200 hover:border-teal-300 hover:bg-teal-50 text-teal-700 px-6 md:px-7 py-3 rounded-2xl transition-all duration-200 font-semibold",
    ghost:
      "inline-flex items-center justify-center text-gray-600 hover:text-teal-600 px-5 md:px-6 py-2.5 rounded-2xl transition-all duration-200",
    nav: "inline-flex items-center justify-center bg-teal-600 text-white px-4 md:px-5 py-2 rounded-xl transition-all duration-200 font-medium text-sm",
  },
  surfaces: {
    page: "bg-white",
    section: "bg-white",
    sectionAlt: "bg-teal-50/30",
    card: "bg-white border border-gray-100 rounded-2xl shadow-md hover:shadow-lg transition-all duration-300",
    cardFeatured: "bg-gradient-to-b from-white to-teal-50/40 border border-teal-100 rounded-2xl shadow-lg",
    input:
      "w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none transition-all",
    badge: "inline-flex items-center px-3 py-1 bg-teal-50 text-teal-700 text-xs font-semibold rounded-full",
    divider: "border-t border-gray-100",
  },
  navigation: {
    wrapper: "bg-white/80 backdrop-blur-lg border-b border-gray-100 sticky top-0 z-50",
    link: "text-gray-600 hover:text-teal-600 transition-colors duration-200 font-medium",
    active: "text-teal-600 font-semibold",
    mobileMenu: "bg-white/90 backdrop-blur-lg border border-gray-100 rounded-2xl shadow-xl",
  },
  effects: {
    shadow: "shadow-lg shadow-gray-900/5",
    shadowHeavy: "shadow-xl shadow-teal-900/10",
    gradient: "bg-gradient-to-b from-white via-teal-50/20 to-white",
    glow: "ring-1 ring-teal-500/10 shadow-[0_0_80px_-20px_rgba(20,184,166,0.2)]",
    hover: "hover:scale-[1.01]",
    transition: "transition-all duration-300",
    animation: "duration-300 ease-in-out",
  },
  sections: {
    hero: "relative overflow-hidden",
    feature: "relative",
    featureGrid: "grid md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-7",
    testimonials: "grid md:grid-cols-2 lg:grid-cols-3 gap-6",
    pricing: "grid lg:grid-cols-3 gap-6 lg:gap-8 items-stretch",
    cta: "relative rounded-3xl border border-teal-100 bg-gradient-to-br from-white to-teal-50/40 p-8 md:p-12",
    footer: "border-t border-teal-100/80 bg-teal-50/20",
  },
  colors: {
    primary: "#0D9488",
    secondary: "#0F766E",
    accent: "#14B8A6",
    background: "#FFFFFF",
    surface: "#F0FDFA",
    surfaceAlt: "#ECFEFF",
    text: "#134E4A",
    textMuted: "#5F6B6B",
    border: "#CCFBF1",
    success: "#059669",
    warning: "#D97706",
    danger: "#DC2626",
  },
};

const preset_commerce_grid: DesignPreset = {
  id: "commerce_grid",
  label: "Commerce Grid",
  category: "commerce",
  themeMode: "light",
  accentStrategy: "vibrant",
  description: "Compacte grids, duidelijke prijsblokken, commerciële hiërarchie.",
  bestFor: ["Dichte productgrids", "Prijstabellen", "Veel items op één scherm"],
  mood: ["Commercieel", "Helder", "Functioneel"],
  layout: {
    container: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
    containerWide: "max-w-[96rem] mx-auto px-4 sm:px-6 lg:px-8",
    containerNarrow: "max-w-4xl mx-auto px-4 sm:px-6 lg:px-8",
    sectionSpacing: "py-12 md:py-16 lg:py-20",
    sectionSpacingTight: "py-8 md:py-12",
    sectionSpacingLoose: "py-20 md:py-28",
    containerPadding: "px-4 sm:px-6 lg:px-8",
    gridGap: "gap-4 md:gap-6 lg:gap-8",
    radius: "rounded-xl",
  },
  typography: {
    heading: "font-sans text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900 tracking-tight",
    subheading: "text-base md:text-lg text-gray-600 max-w-2xl",
    body: "text-sm md:text-base text-gray-700 leading-relaxed",
    caption: "text-xs text-gray-500",
    eyebrow: "text-xs font-bold uppercase tracking-wider text-orange-600",
  },
  buttons: {
    primary:
      "inline-flex items-center justify-center bg-orange-600 hover:bg-orange-700 text-white px-6 py-3 rounded-xl font-semibold shadow-md hover:shadow-lg transition-all w-full sm:w-auto justify-center",
    secondary:
      "inline-flex items-center justify-center border-2 border-gray-900 text-gray-900 hover:bg-gray-900 hover:text-white px-6 py-3 rounded-xl font-semibold transition-all",
    ghost: "inline-flex items-center justify-center text-gray-600 hover:text-orange-600 px-4 py-2 text-sm font-medium",
    nav: "inline-flex items-center justify-center bg-gray-900 text-white px-4 py-2 rounded-lg text-sm font-medium",
  },
  surfaces: {
    page: "bg-white",
    section: "bg-white",
    sectionAlt: "bg-gray-50",
    card: "bg-white border border-gray-200 rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow",
    cardFeatured: "bg-orange-50 border border-orange-100 rounded-xl p-6",
    input:
      "w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:border-orange-500 focus:ring-1 focus:ring-orange-500 outline-none text-sm",
    badge: "inline-flex items-center px-2 py-0.5 bg-red-100 text-red-700 text-xs font-bold rounded",
    divider: "border-t border-gray-200",
  },
  navigation: {
    wrapper: "bg-white border-b border-gray-200 sticky top-0 z-50",
    link: "text-gray-700 hover:text-orange-600 text-sm font-medium",
    active: "text-orange-600 font-semibold",
    mobileMenu: "bg-white border border-gray-200 rounded-xl shadow-lg",
  },
  effects: {
    shadow: "shadow-md shadow-gray-900/5",
    shadowHeavy: "shadow-xl shadow-gray-900/10",
    gradient: "bg-gradient-to-b from-white to-gray-50",
    glow: "",
    hover: "hover:-translate-y-0.5",
    transition: "transition-all duration-200",
    animation: "duration-200 ease-out",
  },
  sections: {
    hero: "relative",
    feature: "relative",
    featureGrid: "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6",
    testimonials: "grid md:grid-cols-3 gap-6",
    pricing: "grid md:grid-cols-2 lg:grid-cols-4 gap-4 items-stretch",
    cta: "rounded-2xl border border-gray-200 bg-gray-900 text-white p-8 md:p-10",
    footer: "border-t border-gray-200 bg-gray-50",
  },
  colors: {
    primary: "#EA580C",
    secondary: "#C2410C",
    accent: "#F97316",
    background: "#FFFFFF",
    surface: "#F9FAFB",
    surfaceAlt: "#FFF7ED",
    text: "#111827",
    textMuted: "#6B7280",
    border: "#E5E7EB",
    success: "#16A34A",
    warning: "#F59E0B",
    danger: "#DC2626",
  },
};

const preset_energetic_light: DesignPreset = {
  id: "energetic_light",
  label: "Energetic Light",
  category: "tech",
  themeMode: "light",
  accentStrategy: "vibrant",
  description: "Emerald accenten, lichte achtergrond, actieve CTA’s.",
  bestFor: ["Launch pages", "Waitlists", "Heldere funnel-blokken"],
  mood: ["Energiek", "Optimistisch", "Direct"],
  layout: {
    container: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
    containerWide: "max-w-[92rem] mx-auto px-4 sm:px-6 lg:px-8",
    containerNarrow: "max-w-2xl mx-auto px-4 text-center",
    sectionSpacing: "py-16 md:py-24",
    sectionSpacingTight: "py-10 md:py-14",
    sectionSpacingLoose: "py-24 md:py-32",
    containerPadding: "px-4 sm:px-6 lg:px-8",
    gridGap: "gap-6 lg:gap-8",
    radius: "rounded-2xl",
  },
  typography: {
    heading: "font-sans text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-extrabold tracking-tight text-gray-900",
    subheading: "text-lg md:text-xl text-gray-600 max-w-2xl mx-auto",
    body: "text-base md:text-lg text-gray-700",
    caption: "text-sm font-medium text-gray-500",
    eyebrow: "text-sm font-bold uppercase tracking-wider text-emerald-600",
  },
  buttons: {
    primary:
      "inline-flex items-center justify-center bg-emerald-500 hover:bg-emerald-600 text-white px-8 py-3.5 rounded-2xl font-bold shadow-lg shadow-emerald-500/25 hover:-translate-y-0.5 transition-all",
    secondary:
      "inline-flex items-center justify-center bg-gray-100 hover:bg-gray-200 text-gray-900 px-8 py-3.5 rounded-2xl font-semibold transition-all",
    ghost:
      "inline-flex items-center justify-center text-gray-600 hover:text-emerald-600 px-6 py-2.5 rounded-xl font-medium",
    nav: "inline-flex items-center justify-center bg-gray-900 text-white px-5 py-2 rounded-xl text-sm font-semibold hover:bg-black",
  },
  surfaces: {
    page: "bg-white",
    section: "bg-white",
    sectionAlt: "bg-emerald-50/40",
    card: "bg-white border border-gray-100 rounded-2xl p-6 shadow-md hover:shadow-lg transition-all",
    cardFeatured: "bg-gradient-to-br from-emerald-500 to-teal-600 text-white rounded-2xl p-8 shadow-xl",
    input:
      "w-full px-4 py-3 border border-gray-200 rounded-xl focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 outline-none",
    badge: "inline-flex items-center px-3 py-1 bg-emerald-100 text-emerald-800 text-xs font-bold rounded-full",
    divider: "border-t border-gray-100",
  },
  navigation: {
    wrapper: "bg-white/90 backdrop-blur border-b border-gray-100 sticky top-0 z-50",
    link: "text-gray-600 hover:text-gray-900 font-medium",
    active: "text-emerald-600 font-semibold",
    mobileMenu: "bg-white border border-gray-100 rounded-2xl shadow-xl",
  },
  effects: {
    shadow: "shadow-lg shadow-gray-900/5",
    shadowHeavy: "shadow-2xl shadow-emerald-900/10",
    gradient: "bg-gradient-to-b from-white to-emerald-50/30",
    glow: "shadow-[0_0_80px_-20px_rgba(16,185,129,0.35)]",
    hover: "hover:scale-[1.02]",
    transition: "transition-all duration-300",
    animation: "duration-300 ease-out",
  },
  sections: { ...sectionsStandard },
  colors: {
    primary: "#10B981",
    secondary: "#059669",
    accent: "#34D399",
    background: "#FFFFFF",
    surface: "#ECFDF5",
    surfaceAlt: "#D1FAE5",
    text: "#064E3B",
    textMuted: "#6B7280",
    border: "#D1FAE5",
    success: "#059669",
    warning: "#F59E0B",
    danger: "#EF4444",
  },
};

const preset_bold_brutalist: DesignPreset = {
  id: "bold_brutalist",
  label: "Bold Brutalist",
  category: "bold",
  themeMode: "light",
  accentStrategy: "vibrant",
  description: "Harde randen, harde schaduwen, mono + geel accent.",
  bestFor: ["Statement layouts", "Studio-achtige campagnes", "Hoge contrasten"],
  mood: ["Raw", "Luid", "Grafisch"],
  layout: {
    container: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
    containerWide: "max-w-[90rem] mx-auto px-4 sm:px-6 lg:px-8",
    containerNarrow: "max-w-3xl mx-auto px-4 sm:px-6 lg:px-8",
    sectionSpacing: "py-20 md:py-28",
    sectionSpacingTight: "py-12 md:py-16",
    sectionSpacingLoose: "py-24 md:py-32",
    containerPadding: "px-4 sm:px-6 lg:px-8",
    gridGap: "gap-6 lg:gap-8",
    radius: "rounded-none",
  },
  typography: {
    heading: "font-mono text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-bold tracking-tighter text-black uppercase",
    subheading: "font-mono text-lg md:text-xl text-gray-800 max-w-2xl",
    body: "font-sans text-base md:text-lg text-gray-800 leading-relaxed",
    caption: "font-mono text-xs text-gray-600 uppercase tracking-wider",
    eyebrow: "font-mono text-xs font-bold uppercase tracking-widest text-black",
  },
  buttons: {
    primary:
      "inline-flex items-center justify-center bg-yellow-400 hover:bg-yellow-300 text-black px-6 py-3 border-2 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] transition-all duration-200 font-bold",
    secondary:
      "inline-flex items-center justify-center bg-white hover:bg-gray-100 text-black px-6 py-3 border-2 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] transition-all duration-200 font-bold",
    ghost:
      "inline-flex items-center justify-center text-black hover:bg-yellow-100 px-5 py-2.5 border-2 border-transparent hover:border-black font-mono font-bold",
    nav: "inline-flex items-center justify-center bg-black text-white px-4 py-2 border-2 border-black font-mono text-sm font-bold",
  },
  surfaces: {
    page: "bg-white",
    section: "bg-white",
    sectionAlt: "bg-yellow-50",
    card: "bg-white border-2 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] p-6 hover:shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transition-all duration-200",
    cardFeatured: "bg-yellow-400 border-2 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] p-8",
    input:
      "w-full px-4 py-3 border-2 border-black bg-white focus:outline-none focus:ring-2 focus:ring-yellow-400 font-mono",
    badge: "inline-flex items-center px-3 py-1 bg-black text-white font-mono text-xs border-2 border-black",
    divider: "border-t-2 border-black",
  },
  navigation: {
    wrapper: "bg-white border-b-2 border-black sticky top-0 z-50",
    link: "text-black hover:text-yellow-600 font-mono font-bold transition-colors",
    active: "text-yellow-600 underline decoration-2 underline-offset-4",
    mobileMenu: "bg-white border-2 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]",
  },
  effects: {
    shadow: "shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]",
    shadowHeavy: "shadow-[12px_12px_0px_0px_rgba(0,0,0,1)]",
    gradient: "bg-gradient-to-br from-white via-yellow-50 to-white",
    glow: "",
    hover: "hover:-translate-y-0.5",
    transition: "transition-all duration-200",
    animation: "duration-200 ease-in-out",
  },
  sections: {
    ...sectionsStandard,
    cta: "border-2 border-black bg-yellow-400 p-8 md:p-12 shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]",
    footer: "border-t-2 border-black bg-white",
  },
  colors: {
    primary: "#000000",
    secondary: "#FACC15",
    accent: "#FF3366",
    background: "#FFFFFF",
    surface: "#FAFAFA",
    surfaceAlt: "#FEF9C3",
    text: "#000000",
    textMuted: "#4B5563",
    border: "#000000",
    success: "#16A34A",
    warning: "#CA8A04",
    danger: "#DC2626",
  },
};

const preset_modern_mono: DesignPreset = {
  id: "modern_mono",
  label: "Modern Mono",
  category: "tech",
  themeMode: "light",
  accentStrategy: "monochrome",
  description: "Zwart/wit, grote type, harde CTA — minimaal en krachtig.",
  bestFor: ["Monochrome landings", "Developer tools aesthetic", "Sterke typografie"],
  mood: ["Bold", "Minimal", "Scherp"],
  layout: {
    container: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
    containerWide: "max-w-[90rem] mx-auto px-4 sm:px-6 lg:px-8",
    containerNarrow: "max-w-3xl mx-auto px-4 sm:px-6 lg:px-8",
    sectionSpacing: "py-24 md:py-32 lg:py-40",
    sectionSpacingTight: "py-16 md:py-20",
    sectionSpacingLoose: "py-32 md:py-40",
    containerPadding: "px-4 sm:px-6 lg:px-8",
    gridGap: "gap-8 lg:gap-10",
    radius: "rounded-3xl",
  },
  typography: {
    heading:
      "font-sans text-5xl md:text-6xl lg:text-7xl xl:text-8xl font-black tracking-tighter bg-gradient-to-r from-gray-900 via-gray-800 to-gray-900 bg-clip-text text-transparent",
    subheading: "text-xl md:text-2xl text-gray-500 font-medium max-w-2xl",
    body: "text-base md:text-lg text-gray-600 leading-relaxed",
    caption: "text-sm text-gray-400 font-mono",
    eyebrow: "text-sm font-semibold uppercase tracking-[0.12em] text-gray-900",
  },
  buttons: {
    primary:
      "inline-flex items-center justify-center bg-black hover:bg-gray-900 text-white px-8 py-4 rounded-full transition-all duration-200 font-semibold shadow-xl hover:shadow-2xl hover:scale-105",
    secondary:
      "inline-flex items-center justify-center bg-white border-2 border-black hover:bg-black hover:text-white text-black px-8 py-4 rounded-full transition-all duration-200 font-semibold",
    ghost:
      "inline-flex items-center justify-center text-gray-600 hover:text-black px-6 py-3 rounded-full transition font-medium",
    nav: "inline-flex items-center justify-center bg-black text-white hover:bg-gray-900 px-4 py-2 rounded-full text-sm font-medium",
  },
  surfaces: {
    page: "bg-white",
    section: "bg-white",
    sectionAlt: "bg-gray-50",
    card: "bg-white border border-gray-100 rounded-3xl shadow-xl hover:shadow-2xl transition-all duration-300",
    cardFeatured: "bg-gray-900 text-white rounded-3xl shadow-2xl p-8 md:p-10",
    input:
      "w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:border-black focus:ring-2 focus:ring-black/10 outline-none transition",
    badge: "inline-flex items-center px-3 py-1 bg-gray-900 text-white text-xs font-mono rounded-full",
    divider: "border-t border-gray-200",
  },
  navigation: {
    wrapper: "bg-white/80 backdrop-blur-xl border-b border-gray-100 sticky top-0 z-50",
    link: "text-gray-600 hover:text-black transition-colors font-medium",
    active: "text-black font-semibold",
    mobileMenu: "bg-white/95 backdrop-blur-xl border border-gray-200 rounded-2xl shadow-xl",
  },
  effects: {
    shadow: "shadow-2xl shadow-black/5",
    shadowHeavy: "shadow-[0_40px_100px_-30px_rgba(0,0,0,0.2)]",
    gradient: "bg-gradient-to-br from-white via-gray-50 to-white",
    glow: "",
    hover: "hover:-translate-y-1",
    transition: "transition-all duration-300",
    animation: "duration-500 ease-out",
  },
  sections: { ...sectionsStandard },
  colors: {
    primary: "#000000",
    secondary: "#1A1A1A",
    accent: "#FF5A5F",
    background: "#FFFFFF",
    surface: "#FAFAFA",
    surfaceAlt: "#F4F4F5",
    text: "#000000",
    textMuted: "#666666",
    border: "#E5E5E5",
    success: "#22C55E",
    warning: "#F59E0B",
    danger: "#EF4444",
  },
};

const designPresetsMap = {
  minimal_dark: preset_minimal_dark,
  minimal_light: preset_minimal_light,
  glass: preset_glass,
  luxury: preset_luxury,
  corporate: preset_corporate,
  editorial: preset_editorial,
  playful: preset_playful,
  tech_saas: preset_tech_saas,
  organic_soft: preset_organic_soft,
  commerce_grid: preset_commerce_grid,
  energetic_light: preset_energetic_light,
  bold_brutalist: preset_bold_brutalist,
  modern_mono: preset_modern_mono,
} satisfies Record<string, DesignPreset>;

export const designPresets = designPresetsMap;

export type PresetId = keyof typeof designPresets;

/** Oude `brand_style`-id’s → nieuwe visuele preset (backwards compatible). */
export const LEGACY_PRESET_IDS = {
  premium_minimal_dark: "minimal_dark",
  premium_dark: "minimal_dark",
  glass_premium: "glass",
  enterprise_corp: "corporate",
  ultra_luxury: "luxury",
  creative_agency: "playful",
  healthcare_wellness: "organic_soft",
  editorial_refined: "editorial",
  premium_tech: "tech_saas",
  modern_saas: "modern_mono",
  minimal_luxury: "minimal_light",
  neubrutalist: "bold_brutalist",
  startup_launch: "energetic_light",
  ecommerce_shop: "commerce_grid",
} as const satisfies Record<string, PresetId>;

/** Standaard licht: voorkomt dat elke generatie zonder keyword-match op `minimal_dark` uitkomt. */
export const DEFAULT_PRESET_ID: PresetId = "minimal_light";

export function isPresetId(value: string): value is PresetId {
  return value in designPresets;
}

/** Map oude of onbekende id’s naar een geldige preset key. */
export function resolveBrandStyleToPresetId(raw: string): PresetId {
  const t = raw.trim();
  if (!t) return DEFAULT_PRESET_ID;
  if (isPresetId(t)) return t;
  const mapped = LEGACY_PRESET_IDS[t as keyof typeof LEGACY_PRESET_IDS];
  if (mapped) return mapped;
  return DEFAULT_PRESET_ID;
}

export function getDesignPreset(brandStyle?: string): DesignPreset {
  const id = brandStyle ? resolveBrandStyleToPresetId(brandStyle) : DEFAULT_PRESET_ID;
  return designPresets[id];
}

export function getAllPresetIds(): PresetId[] {
  return Object.keys(designPresets) as PresetId[];
}

export function getAllPresets(): DesignPreset[] {
  return Object.values(designPresets);
}

export function getPresetMetadata(): Record<
  PresetId,
  Pick<
    DesignPreset,
    | "id"
    | "label"
    | "category"
    | "themeMode"
    | "accentStrategy"
    | "description"
    | "bestFor"
    | "mood"
  >
> {
  return Object.fromEntries(
    Object.entries(designPresets).map(([key, p]) => [
      key,
      {
        id: p.id,
        label: p.label,
        category: p.category,
        themeMode: p.themeMode,
        accentStrategy: p.accentStrategy,
        description: p.description,
        bestFor: p.bestFor,
        mood: p.mood,
      },
    ]),
  ) as Record<
    PresetId,
    Pick<
      DesignPreset,
      | "id"
      | "label"
      | "category"
      | "themeMode"
      | "accentStrategy"
      | "description"
      | "bestFor"
      | "mood"
    >
  >;
}
