/**
 * Schatting in USD op basis van getelde tokens.
 * Standaardwaarden zijn indicatief voor Sonnet-achtige modellen; pas aan via env
 * zodat ze aansluiten op jouw actuele Anthropic-prijzen.
 *
 * Zie: https://www.anthropic.com/pricing
 */
export function estimateAnthropicUsdFromUsage(usage: {
  input_tokens: number;
  output_tokens: number;
  cache_creation_input_tokens?: number | null;
  cache_read_input_tokens?: number | null;
}): number {
  const inputPerM = Number(process.env.ANTHROPIC_PRICE_INPUT_PER_MTOK_USD ?? "3");
  const outputPerM = Number(process.env.ANTHROPIC_PRICE_OUTPUT_PER_MTOK_USD ?? "15");
  const cacheReadPerM = Number(
    process.env.ANTHROPIC_PRICE_CACHE_READ_PER_MTOK_USD ?? String(inputPerM * 0.1),
  );
  const cacheWritePerM = Number(
    process.env.ANTHROPIC_PRICE_CACHE_WRITE_PER_MTOK_USD ?? String(inputPerM * 1.25),
  );

  const baseIn = Math.max(0, usage.input_tokens);
  const out = Math.max(0, usage.output_tokens);
  const cacheRead = Math.max(0, usage.cache_read_input_tokens ?? 0);
  const cacheWrite = Math.max(0, usage.cache_creation_input_tokens ?? 0);

  const usd =
    (baseIn / 1_000_000) * inputPerM +
    (out / 1_000_000) * outputPerM +
    (cacheRead / 1_000_000) * cacheReadPerM +
    (cacheWrite / 1_000_000) * cacheWritePerM;

  return Math.round(usd * 10_000) / 10_000;
}

export function usdToEurDisplay(usd: number): number | null {
  const rate = process.env.ANTHROPIC_EUR_PER_USD;
  if (!rate) return null;
  const n = Number(rate);
  if (!Number.isFinite(n) || n <= 0) return null;
  return Math.round(usd * n * 100) / 100;
}

export function getMonthlyBudgetUsd(): number | null {
  const raw = process.env.ANTHROPIC_MONTHLY_BUDGET_USD;
  if (raw == null || raw === "") return null;
  const n = Number(raw);
  if (!Number.isFinite(n) || n <= 0) return null;
  return n;
}
