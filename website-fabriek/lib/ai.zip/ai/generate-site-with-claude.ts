import { randomUUID } from "node:crypto";
import Anthropic from "@anthropic-ai/sdk";
import { ANTHROPIC_KEY_MISSING_USER_HINT, getAnthropicApiKey } from "@/lib/ai/anthropic-env";
import type { ContentBlockParam } from "@anthropic-ai/sdk/resources/messages";
import type { MessageDeltaUsage } from "@anthropic-ai/sdk/resources/messages/messages";
import { buildHomepagePlan, type HomepagePlan } from "@/lib/ai/build-homepage-plan";
import {
  buildSiteConfig,
  mergeExtractedDesignIntoSiteConfig,
  type ExtractedDesignFromImage,
  type SiteConfig,
} from "@/lib/ai/build-site-config";
import { buildCompactnessPromptBlock } from "@/lib/ai/build-compactness-prompt-block";
import {
  applyHomepageCompactnessToSiteConfig,
  buildHomepageCompactnessPlan,
  type HomepageCompactnessPlan,
} from "@/lib/ai/homepage-compactness-plan";
import { getDesignPreset } from "@/lib/ai/design-presets";
import { extractDesignFromImage, findFirstKnowledgeImageUrl } from "@/lib/ai/extract-design-from-image";
import { buildCompositionDecisionTrace } from "@/lib/ai/composition-decision-trace";
import { buildCompositionDebugPayload, type CompositionDebugPayload } from "@/lib/ai/composition-debug-payload";
import {
  getEffectiveHeroExpression,
  resolveFinalDesignRegime,
} from "@/lib/ai/above-fold-archetypes";
import { resolveCompositionPlan } from "@/lib/ai/resolve-composition-plan";
import { buildStudioPromptLayoutMaps } from "@/lib/ai/studio-prompt-layout-maps";
import {
  buildStudioStructurePromptBlock,
  buildStudioStructurePromptBlockForUpgrade,
} from "@/lib/ai/studio-structure-layer";
import { getKnowledgeContextForClaude } from "@/lib/data/ai-knowledge";
import { buildContentAuthorityPolicyBlock } from "@/lib/ai/content-authority-policy";
import { buildContentClaimDiagnosticsReport } from "@/lib/ai/content-claim-diagnostics";
import { MASTER_SITE_SYSTEM_PROMPT } from "@/lib/ai/master-site-system-prompt";
import { parseModelJsonObject } from "@/lib/ai/extract-json";
import {
  claudeTailwindPageOutputSchema,
  mapClaudeOutputToSections,
  type GeneratedTailwindPage,
  type MasterPromptPageConfig,
  type TailwindSection,
} from "@/lib/ai/tailwind-sections-schema";
import { getGenerationPackagePromptBlock } from "@/lib/ai/generation-packages";
import { logClaudeMessageUsage } from "@/lib/ai/log-claude-message-usage";
import { getAlpineInteractivityPromptBlock } from "@/lib/ai/interactive-alpine-prompt";
import {
  normalizeHtmlWhitespaceForUpgradePrompt,
  postProcessClaudeTailwindPage,
  stableIdsForUpgradeSections,
} from "@/lib/ai/generate-site-postprocess";
import { buildLovableThemeDirectiveBlock } from "@/lib/ai/theme-lovable-hints";
import { tryExtractCompletedSections } from "@/lib/ai/stream-json-section-extractor";
import { parseStoredSiteData } from "@/lib/site/parse-stored-site-data";
import { validateGeneratedPageHtml } from "@/lib/ai/validate-generated-page";
import { validateHomepagePlan } from "@/lib/ai/validate-homepage-plan";
import {
  buildAntiGenericCopyPromptBlock,
  type AntiGenericCopyContext,
} from "@/lib/ai/anti-generic-copy-prompt";
import { isBrandLogoSystemEnabled } from "@/lib/branding/brand-logo-env";
import { buildBrandLogoPromptAppendix, runPremiumLogoPipeline } from "@/lib/branding/generate-logo-system";
import type { GeneratedLogoSet } from "@/types/logo";

const DEFAULT_MODEL = "claude-sonnet-4-20250514";
/** Grote Premium/Custom-sites; site-generatie gebruikt streaming, dus boven ~21k mag (per API/model). */
const DEFAULT_MAX_OUTPUT_TOKENS = 24_576;

function fnv1aHash(input: string): number {
  let h = 2166136261;
  for (let i = 0; i < input.length; i++) {
    h ^= input.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function formatRecentClientsLine(names: string[]): string {
  if (names.length === 0) {
    return "(Nog geen eerdere klanten in de database — kies desondanks een maximaal unieke layout, kleuren en sectie-volgorde.)";
  }
  return names.map((n) => `“${n.replace(/"/g, "'")}”`).join(", ");
}

const NAV_LAYOUT_MANDATES = [
  "Glazen topbalk: `backdrop-blur-md` + `bg-white/70` of `bg-slate-900/35` met dunne border; logo en nav op **één regel** maar nav **niet** de standaard ‘alles klemt rechts’: gebruik bijv. `justify-center` met logo boven de nav in een **kolom** op desktop (`flex-col items-center`) of nav gecentreerd onder het woordmerk.",
  "Woordmerk **centraal** bovenaan, daaronder een **horizontale** nav (`flex flex-wrap justify-center gap-x-6 gap-y-2`), pas daarna headline/CTA — geen klassieke SaaS-navbar links+rechts.",
  "Header als **twee rijen**: eerste rij alleen merknaam (links of center), tweede rij nav-links als rustige tekstlinks (`border-t border-opacity-20`); mobiel: stapel netjes.",
  "‘Floating’ nav: nav in een **pill** (`rounded-full border shadow-sm px-4 py-2`) die **los** van de rand zweeft (bijv. `mx-auto mt-4 max-w-3xl`), eventueel semi-transparant; hero-content daaronder.",
  "Split-kop: merk **links** in sterke typografie, nav **rechts** maar in een **verticale stack** of **kolom** onder het merk op brede schermen (`lg:flex-col lg:items-start`) — dus **niet** elke keer één horizontale balk rechtsboven.",
  "Minimal: extreem dunne header (`py-3`), nav **midden** op de pagina (`absolute left-1/2 -translate-x-1/2` binnen `relative` hero) of onder het logo; veel witruimte.",
] as const;

const ACCENT_FAMILY_MANDATES = [
  "Accent-familie **teal/petrol** (vertrouwd, fris): bijv. `#0f7669`, `#0d9488`, `#115e59` — **niet** oranje tenzij de branche expliciet warm/food vraagt.",
  "Accent-familie **violet/indigo** (premium tech): bijv. `#5b21b6`, `#6d28d9`, `#4f46e5` — contrasteer met lichte of zandkleurige basis.",
  "Accent-familie **robijn/roze** (energie, zorg, lifestyle): bijv. `#9f1239`, `#be123c`, `#db2777` — alleen op knoppen en highlights.",
  "Accent-familie **elektrisch blauw** (SaaS, finance): bijv. `#1d4ed8`, `#2563eb`, `#1e40af` op warme of grijze achtergrond.",
  "Accent-familie **mosterd/oker** (warm, niet standaard orange): bijv. `#a16207`, `#ca8a04` gecombineerd met **navy** als primary — vermijd `#f97316` als default.",
  "Accent-familie **smaragd/bos** (groei, duurzaamheid, gezondheid): bijv. `#047857`, `#059669`, `#065f46`.",
  "Accent-familie **slate + koper** (luxury modern): CTA in `#b45309` / `#c2410c` (koper) of diep `#0c4a6e` i.p.v. fel oranje.",
] as const;

const UNSPLASH_MOOD_CHIPS = [
  "abstract texture, architecture detail, crafted material",
  "minimal interior, natural light, workspace still life",
  "landscape horizon, calm water, soft gradient sky",
  "urban geometry, shadows, monochrome building",
  "botanical macro, organic pattern, soft green",
  "hands craft, tools detail, authentic process",
] as const;

const LUCIDE_ROTATION_HINTS = [
  "Sparkles, Compass, Layers, Gem, Orbit, Hexagon, Workflow, Telescope",
  "Mountain, SunMedium, Leaf, Droplets, ShieldCheck, Landmark, Palette, Box",
  "Zap, Cpu, Network, GitBranch, Gauge, Target, Trophy, Medal",
  "HeartPulse, Stethoscope, Building2, Briefcase, Scale, BookOpen, Lightbulb",
] as const;

/** Per generatie één harde compositie-opdracht — breekt “alles is een kadertje” (Lovable-niveau = ritme + contrast). */
const COMPOSITION_MANDATES = [
  "**Full-bleed of breakout:** minstens één sectie met een **bredere visuele band** dan je standaard contentcontainer: zet `bg-*`, gradient of breed beeld op een **buitenste** wrapper (sectie-vlak over volle beschikbare breedte) terwijl tekst binnen `max-w-*` gecentreerd blijft — zo breekt het ritme t.o.v. secties die alleen een smalle kolom op wit hebben.",
  "**Features zonder card-muur:** geen drie identieke “icoon + titel + zin in `rounded-2xl border bg-*-50`”. Kies **ongelijk raster** (`md:grid-cols-4` met één item `md:col-span-2`), of **verticale lijst** met `gap` + `divide-y`, of **twee kolommen** waarin één kolom een **grote** visuele lead (cijfer, citaat, beeld) is.",
  "**Testimonials editorial:** geen gestapelde grijze quote-boxes. Gebruik **grote pull-quote** typografie (`text-3xl`+), of **split** (foto/linkerkant full-height, tekst rechts), of **één** spotlight-quote + kleinere steunzinnen **zonder** dat elk citaat dezelfde card-huls heeft.",
  "**Pricing hiërarchie:** precies **één** plan moet visueel domineren (schaal, contrast, badge); andere plannen **lichter** of compacter — **verboden:** drie identieke witte/teal-rand kaarten naast elkaar. Mag ook **één kolom + vergelijkingstabel** i.p.v. kaarten.",
  "**Hero laag / overlap:** beeld en kop **raken elkaar** compositorisch (`relative`, negatieve marge, of `lg:grid-cols-12` met asymmetrische spans) — niet altijd strakke 50/50 twee kolommen met perfecte rechthoek.",
  "**Tonal rhythm:** wissel sectie-achtergronden op **sectie-niveau** (heel vlak `bg-*-50` / gradient) — **niet** alleen witte pagina met inner boxes. Minstens **één** midden-sectie zonder inner “card grid” (alleen type + media + witruimte).",
  "**Type-strip:** één band met **oversized** heading (`text-6xl`+), één onderregel, CTA, en **veel** verticale witruimte — **geen** rij subcards eronder in diezelfde sectie.",
  "**Bento-light:** features in **ongelijk** raster (verschillende `col-span` / `row-span` met standaard grid) — expliciet **niet** `md:grid-cols-3` met drie gelijke tegels.",
] as const;

function buildVarianceBlock(
  businessName: string,
  description: string,
  recentClientNames: string[],
  varianceNonce?: string,
): string {
  const salt = `${businessName}\n${description.slice(0, 120)}\n${recentClientNames.join(",")}\n${varianceNonce ?? ""}`;
  const h = fnv1aHash(salt);
  const navIdx = h % NAV_LAYOUT_MANDATES.length;
  const accentIdx = (h >> 3) % ACCENT_FAMILY_MANDATES.length;
  const photoIdx = (h >> 7) % UNSPLASH_MOOD_CHIPS.length;
  const iconIdx = (h >> 11) % LUCIDE_ROTATION_HINTS.length;
  const compositionIdx = (h >> 15) % COMPOSITION_MANDATES.length;

  return `=== 0A. MANDAAT VARIATIE (verplicht voor deze opdracht) ===

Je krijgt hieronder **één** gekozen navigatie-indeling, **één** accent-familie, **één compositie-mandaat** (anti-generic / pro-Lovable) en hints voor beeld/iconen. Volg ze — ze bestaan om **template-uiting** (altijd dezelfde oranje CTA, altijd logo-links-nav-rechts, altijd grijze card-grids) te doorbreken.

- **Nav / hero-structuur (${navIdx + 1}/${NAV_LAYOUT_MANDATES.length}):** ${NAV_LAYOUT_MANDATES[navIdx]}
- **Compositie / anti-box (${compositionIdx + 1}/${COMPOSITION_MANDATES.length}) — minstens één sectie moet dit duidelijk in de HTML uitdragen:** ${COMPOSITION_MANDATES[compositionIdx]}
- **Accent-kleur (${accentIdx + 1}/${ACCENT_FAMILY_MANDATES.length}):** ${ACCENT_FAMILY_MANDATES[accentIdx]}
- **Unsplash-sfeer (kies 2–4 passende zoektermen uit):** ${UNSPLASH_MOOD_CHIPS[photoIdx]}
- **Lucide-rotatie (varieer per sectie; kies uit deze set + andere geldige Lucide-namen):** ${LUCIDE_ROTATION_HINTS[iconIdx]}

**Anti-generic “AI SaaS”:** het patroon \`bg-slate-50\` / \`bg-gray-50\` + \`rounded-2xl\` + \`border\` + \`p-6\` op **elk** blok is **verboden** als standaard. Max. **twee** dergelijke boxed tiles per pagina (bijv. uitgelichte pricing); de rest: open layout, tonal bands, type-led, of divide-y.

**Anti-oranje:** gebruik **geen** standaard Tailwind-orange (\`orange-500\`, \`#f97316\`) als vaste CTA-kleur tenzij de branche (bijv. food, bouw, deals) dat **inhoudelijk** rechtvaardigt. Kies anders je accent uit de toegewezen familie of een andere **psychologisch passende** complementaire kleur.

**Anti-nav-kloon:** het is **verboden** om zonder reden **zes keer op rij** dezelfde layout te gebruiken: “logo links, nav rechts, alles op één horizontale balk”. Speel met **centering, kolommen, glas, pills, nav onder logo** zoals hierboven.`;
}

function buildUpgradePreserveLayoutBlock(): string {
  return `=== 0A. UPGRADE — BEHOUD LAY-OUT (verplicht; gaat boven standaard-variatie) ===

Deze opdracht is een **uitbreiding** op een bestaande site, **geen** volledige herontwerp-ronde.

- **Negeer** voor deze run het normale “forceer een andere layout / andere nav / andere kleuren”-mandaat (§1 Uniekheids-protocol geldt hier **niet** voor wat al bestaat).
- **Behoud** \`config\` (theme, font, style) **identiek** aan de bestaande site als die hieronder in JSON staat; zo niet beschikbaar, trek \`config\` **strikt** uit de briefing en wees **consistent** met de beschreven huidige look.
- **Behoud** de **html** van elke bestaande marketingsectie **letterlijk** (zelfde Tailwind-classes en structuur), tenzij je **minimaal** een \`href="#…"\` of \`id\` moet toevoegen voor **nieuwe** secties uit de briefing / §0B.
- Voeg **alleen** de **extra** secties/blokken toe die de briefing of §0B vereist (nieuwe \`id\`’s, uniek), op een logische plek in het \`sections\`-array. **Geen** dubbele \`id\`’s.
- **Geen** wholesale redesign: geen andere kleurpalet-keuze, geen andere hero-structuur, geen herschikking “omdat het mooier is” — alleen gerichte uitbreiding.`;
}

function buildUniquenessProtocolSection(recent: string): string {
  return `=== 1. HET UNIEKHEIDS-PROTOCOL (Anti-Template) ===

Je hebt eerder (in dit systeem) websites gegenereerd voor de laatste klanten: ${recent}

STRIKTE OPDRACHT: gebruik voor **deze** aanvraag een **totaal andere** layout, **andere** primaire+accent-combinatie, **andere** hero-structuur en sectie-volgorde dan voor die namen — ook als je “standaard” SaaS-patronen kent. Varieer bewust in:

- **Compositie (niet alleen grids):** editorial canvas, full-bleed hero, zwevende nav-pill, asymmetrische kolommen, type als beeld — **niet** de standaard “alles in gelijkwaardige cards met border”.
- **Grid-structuur:** Bento, asymmetrisch, magazine-kolommen, overlap/lagen, full-bleed vs compacte band — **niet** drie keer dezelfde “drie kolommen met icoon boven titel in een kadertje”. Volg ook **§0A compositie-mandaat** letterlijk voor minstens één sectie.
- **Visuele stijl:** kies **één** duidelijke richting uit:
  - **Modern SaaS** (rust, typografie, subtiele schaduwen — maar **anders** dan een standaard Stripe-clone)
  - **Neubrutalism** (dikke randen, speelse offset — alleen als het bij de branche past)
  - **Minimalist Luxury** (serif-hiërarchie, veel witruimte, dunne lijnen)
  - **Glassmorphism** (\`backdrop-blur\`, \`bg-…/40\` — vooral op **nav/overlay**, niet overal als kaartenbak)
- **Afbeeldingen:** minstens **twee** verschillende Unsplash-url’s met **passende** onderwerpen (zie §0A); wissel **crop/sfeer** (macro, wide, portrait block) — geen identieke “lachende mens op kantoor”-formule elke keer.
- **Iconen:** minstens **vier verschillende** Lucide-namen over de pagina; herhaal niet overal \`Check\` / \`Star\` — gebruik semantisch passende iconen per feature.`;
}

function buildUpgradeMergeSection(): string {
  return `=== 1. UPGRADE — SAMENVOEGEN MET BESTAANDE SITE ===

- Output = **één** geldig JSON-object met \`config\` + \`sections\` zoals in §5.
- **config:** kopieer van de bestaande site (zie JSON hieronder of briefing) **zonder** esthetische wijziging.
- **sections:** de bron-JSON bevat per rij \`id\` (stabiele slug), \`sectionName\` (label) en \`html\`. Behoud **exact** dezelfde \`id\`’s en **dezelfde** \`html\` voor die rijen, in **dezelfde volgorde**; voeg daartussen of aan het eind (logisch) **nieuwe** secties toe volgens briefing / §0B.
- Nieuwe secties: unieke \`id\` (bijv. \`portal\`, \`booking\`, \`client_dashboard\`); inhoud en Tailwind-stijl moeten **visueel aansluiten** op de bestaande secties (zelfde typografie- en kleurgebruik als in de bestaande html).
- Als er **geen** bestaande JSON in de prompt staat: bouw de marketingpagina compact volgens de briefing, maar **zonder** “alles opnieuw verzinnen” — focus op **toevoegen** van gevraagde secties; varieer niet gratuit t.o.v. de beschreven huidige site.`;
}

export type GenerateSitePromptOptions = {
  /** Behoud lay-out/thema; alleen briefing/§0B-uitbreidingen toevoegen. */
  preserveLayoutUpgrade?: boolean;
  /** Genormaliseerde JSON-string (config + sections) van de huidige site, indien bekend. */
  existingSiteTailwindJson?: string | null;
  /**
   * Zout voor §0A-variatie (nav/accent/foto/icon-hints). Bij elke nieuwe generatie wordt standaard
   * een willekeurige waarde gezet zodat dezelfde briefing niet telkens dezelfde mandaten kiest.
   */
  varianceNonce?: string;
  /** Sectie-id’s uit SiteConfig (§5 minimaal-set in de user-prompt). */
  sectionIdsHint?: string[];
  /** Personality / doelen voor anti-generieke copy (gezet door site-generatie; optioneel bij dashboard-preview). */
  copyContext?: AntiGenericCopyContext;
};

const UPGRADE_PROMPT_JSON_MAX = 150_000;

/**
 * Leest stabiele `id`'s uit de Tailwind-upgrade-JSON (zelfde structuur als in de prompt).
 * Voorkomt dat `_site_config.sections` / layout-maps uit een **nieuwe** interpretatie afwijken van de bron-site.
 */
export function extractSectionIdsFromTailwindUpgradeJson(json: string): string[] | null {
  try {
    const o = JSON.parse(json) as { sections?: unknown };
    if (!Array.isArray(o.sections)) return null;
    const ids: string[] = [];
    for (const row of o.sections) {
      if (row && typeof row === "object" && "id" in row) {
        const id = (row as { id: unknown }).id;
        if (typeof id === "string" && id.trim() !== "") ids.push(id);
      }
    }
    return ids.length > 0 ? ids : null;
  } catch {
    return null;
  }
}

/** Bestaande volgorde eerst; daarna geplande id's uit briefing die nog niet op de pagina zitten (nieuwe secties). */
export function mergeUpgradeSectionOrder(existing: string[] | null, planned: readonly string[]): string[] {
  if (!existing?.length) return [...planned];
  const out = [...existing];
  for (const id of planned) {
    if (!out.includes(id)) out.push(id);
  }
  return out;
}

export type SerializeSiteForUpgradeResult =
  | { ok: true; json: string }
  | { ok: false; reason: "not_tailwind" | "too_large" };

/** Maakt een compacte JSON-string voor de Claude-prompt (alleen Tailwind-opgeslagen sites). */
export function serializeExistingSiteForUpgradePrompt(siteData: unknown): SerializeSiteForUpgradeResult {
  const p = parseStoredSiteData(siteData);
  if (!p || p.kind !== "tailwind") {
    return { ok: false, reason: "not_tailwind" };
  }

  const ids = stableIdsForUpgradeSections(p.sections.map((s) => s.sectionName));

  const build = (rows: { id: string; sectionName?: string; html: string }[]) =>
    JSON.stringify({ config: p.config ?? null, sections: rows });

  let json = build(
    p.sections.map((s, i) => ({
      id: ids[i]!,
      sectionName: s.sectionName,
      html: s.html,
    })),
  );
  if (json.length <= UPGRADE_PROMPT_JSON_MAX) {
    return { ok: true, json };
  }

  json = build(
    p.sections.map((s, i) => ({
      id: ids[i]!,
      sectionName: s.sectionName,
      html: normalizeHtmlWhitespaceForUpgradePrompt(s.html),
    })),
  );
  if (json.length <= UPGRADE_PROMPT_JSON_MAX) {
    return { ok: true, json };
  }

  json = build(
    p.sections.map((s, i) => ({
      id: ids[i]!,
      html: normalizeHtmlWhitespaceForUpgradePrompt(s.html),
    })),
  );
  if (json.length <= UPGRADE_PROMPT_JSON_MAX) {
    return { ok: true, json };
  }

  return { ok: false, reason: "too_large" };
}

/** Volledige user-prompt voor site-generatie (o.a. voor admin dashboard-preview). */
export function buildWebsiteGenerationUserPrompt(
  businessName: string,
  description: string,
  recentClientNames: string[],
  options?: GenerateSitePromptOptions,
): string {
  const recent = formatRecentClientsLine(recentClientNames);
  const preserve = Boolean(options?.preserveLayoutUpgrade);
  const variance = preserve
    ? buildUpgradePreserveLayoutBlock()
    : buildVarianceBlock(businessName, description, recentClientNames, options?.varianceNonce);
  const packageBlock = getGenerationPackagePromptBlock(undefined, { preserveLayoutUpgrade: preserve });
  const existingJson = options?.existingSiteTailwindJson?.trim();
  const existingBlock =
    existingJson && existingJson.length > 0
      ? `

=== BESTAANDE SITE (bron voor config + secties; bij upgrade letterlijk behouden) ===

${existingJson}
`
      : "";

  const section1 = preserve ? buildUpgradeMergeSection() : buildUniquenessProtocolSection(recent);

  const psychColorLead = preserve
    ? `In **upgrade-modus met bron-JSON:** negeer “nieuw palet kiezen” — kopieer \`config\` (style, theme, font) **exact** uit de bestaande site. Zonder bron-JSON: trek \`config\` uit de briefing en wijzig die niet gratuit.\n\n`
    : "";

  const section3Tail = preserve
    ? `\n- **Upgrade-modus:** wijzig geen bestaande sectie-\`html\` tenzij minimaal nodig voor nieuwe \`#id\`-links; nieuwe secties sluiten qua Tailwind-stijl aan op de bestaande blokken.\n`
    : "";

  const section3HeroHeight = preserve
    ? ""
    : `\n- **Hero-hoogte (embedded preview):** Stapel **niet** \`min-h-screen\` met zware \`py-*\` op **dezelfde** hero-wrapper — dat maakt de pagina extreem lang in iframes. Kies **hoogstens één** sterke hoogte-eis (bijv. \`min-h-[60vh]\`–\`min-h-[75vh]\` **of** ruime padding **zonder** tegelijk volledige viewport-hoogte). Vermijd een groot leeg gekleurde vlak zonder inhoud.\n`;

  const section3LayoutArchetypes = preserve
    ? ""
    : `\n- **Layout-archetypes (Studio):** Voor elke sectie in \`_layout_archetypes\` (zie STUDIO STRUCTUUR): root-\`<section id="…">\` ook \`data-layout="…"\`; belangrijke blokken binnenin wrappen met \`data-slot="…"\` volgens de **slot-lijst** bij dat archetype — geen verzonnen layout-/slot-id’s.\n`;

  const section3VisualRichness = preserve
    ? ""
    : `\n- **Visuele diepte (verplicht — “platte template” is onvoldoende):** Pas \`_design_preset.effects.gradient\`, \`effects.shadow\` en/of \`effects.glow\` **zichtbaar** toe op de **hero** en op **minstens twee andere** secties op **sectie- of band-niveau** (outer wrapper), samen met \`surfaces.page\` / \`surfaces.section\` / \`surfaces.sectionAlt\` uit hetzelfde preset. **Niet** elke kolom in een aparte “kaart” stoppen — diepte mag op de grote vlakken zitten; binnenin liever typografie + witruimte + beeld.\n- **Anti-box default:** vermijd \`border\` + \`shadow-*\` + afgeronde box om **elk** contentblok. Denk **editorial canvas** (zoals high-end referentiesites): asymmetrie, full-bleed media, overlap (\`-mt-*\`, \`relative\`/\`z-*\`) waar het leesbaar blijft op mobiel.\n- **Beeld / beweging:** minstens **drie verschillende** \`https://images.unsplash.com/...\` foto’s (specifieke \`photo-\` id’s, \`alt\`); hero: sterk beeld **of** gradient + blur-orb **of** (optioneel, max. **één** per pagina) \`<video muted playsinline autoplay loop>\` met betrouwbare \`https://\`-bron — **geen** geluid, geen zware externe embeds.\n- **Contrast:** op lichte achtergronden altijd donkere bodytekst (\`text-slate-900\`, \`text-gray-800\`); op donkere achtergronden lichte body (\`text-gray-100\`–\`200\`). Nooit witte of bijna-witte koppen op wit; geen \`text-gray-300\` voor lange alinea’s op wit.\n- **Compositie:** in features, testimonials, pricing of FAQ minstens **één** sectie met gebroken symmetrie (uitgelichte tier, offset grid, split met beeld, bento-ongelijkheid) **of** een bewust **open** band waarin alleen type + beeld de structuur dragen.\n`;

  const section4Nav = preserve
    ? `- **Nav / upgrade:** behoud navigatie en hero-structuur uit de **bestaande** hero-\`html\`; werk alleen \`href="#…"\` / \`id\` bij waar nieuwe secties dat vereisen.\n`
    : `- **Responsief & nav:** flex/grid met breakpoints. Eerste sectie (meestal \`hero\`) bevat **herkenbare navigatie** volgens **§0A**. Ankerlinks (\`href="#…"\`) moeten exact overeenkomen met de \`id\`’s op de overige secties uit \`_site_config.sections\`.\n`;

  const section5IdsNote = preserve
    ? `\nIn **upgrade-modus:** behoud alle \`id\`’s (en bij voorkeur de \`html\`) van de bron-secties; voeg alleen **nieuwe** secties toe waar de briefing dat vraagt.`
    : "";

  const premiumQualityClause = preserve
    ? "**Premium vorm:** compositie en typografie ook voor **nieuwe** secties — aansluiten op het ritme van de bestaande html; **niet** de default “elke kolom in een bordered card”. (Het volledige PREMIUM CONTRACT staat alleen bij vrije generatie onder STUDIO STRUCTUUR.)"
    : "**Premium vorm:** compositie en typografie eerst — **niet** de default “elke kolom in een bordered card”; zie het **PREMIUM DESIGN SYSTEM CONTRACT** in STUDIO STRUCTUUR (canvas/editorial i.p.v. componentenstapel).";

  const requiredIdsLine =
    options?.sectionIdsHint && options.sectionIdsHint.length > 0
      ? options.sectionIdsHint.map((s) => `\`${s}\``).join(", ")
      : "`hero`, `features`, `testimonials`, `pricing`, `faq`, `footer`";

  const lovableThemeBlock = buildLovableThemeDirectiveBlock({
    preserveLayoutUpgrade: preserve,
    businessName,
    description,
  });

  const antiGenericCopy = buildAntiGenericCopyPromptBlock({
    businessName,
    description,
    recentClientNames,
    varianceNonce: options?.varianceNonce,
    ...options?.copyContext,
  });

  const contentAuthorityBlock = buildContentAuthorityPolicyBlock();

  return `Je bent een senior webdesigner en conversie-specialist. Jouw missie is het genereren van een unieke **premium, editorial** landingpage in JSON-formaat (Tailwind): een **bewuste compositie** op het canvas — met sterke typografie, ritme en witruimte — **niet** een stapel generieke bordered cards of “standaard SaaS-blokken”.

Bedrijfsnaam: ${businessName}
Context / branche: ${description}

${variance}

${antiGenericCopy}

${contentAuthorityBlock}

=== 0B. SITE STUDIO — PRODUCTINSTRUCTIES (strikt volgen; gaat boven algemene uitbreiding) ===

${packageBlock}${existingBlock}

=== 0. ONWIJKBARE KERNINSTRUCTIES (immutable core) ===

1. **Prioriteit:** Jouw rol als senior designer én de **technische JSON-structuur** (zie §5) zijn **onwijzigbaar** — geen verkorte of alternatieve outputvormen.
2. **Logica-check:** Beoordeel impliciet elke wens uit de context: *behoudt dit professionele kwaliteit en een **60-30-10 kleurbalans*** (ca. 60% neutrale achtergrond/witruimte, 30% primaire merktinten, 10% accent/CTA)? Zo niet, herbalanceer subtiel in layout en kleurgebruik. ${premiumQualityClause}
3. **Bescherming:** Vraag nooit om of lever nooit een site die **kernfunctionaliteit** breekt. Behoud **mobiele responsiviteit** (mobile-first Tailwind: \`sm:\` / \`md:\` / \`lg:\`, geen layouts die op kleine schermen onbruikbaar worden). Behoud **duidelijke navigatie** in de header/hero (bedrijfsnaam of logo-tekst + ankertjes naar de belangrijkste secties, of logische \`#id\`-links). Als de gebruikerscontext iets zou suggereren dat dit ondermijnt, kies een **veilige, esthetische** interpretatie die deze kernfuncties waarborgt.
4. **Geheugen-anker:** Je mag **nooit** de verplichte JSON-velden weglaten: het object **moet** altijd \`config\` (inclusief volledig \`theme\` met \`primary\` en \`accent\` en de tinten), en \`sections\` bevatten — ook bij een minimale of eenvoudige opdracht.
5. **Conflict-resolutie:** Als een gewenste kleur of stijl **botst** met de psychologische kleuren-engine van de branche (§2), pas die wens dan **subtiel toe als accent** (knoppen, highlights, details), niet als dominante basis die de hele site overspoelt — professionele standaard gaat voor.
${preserve ? "\n6. **Upgrade-modus:** Als dit botst met §2 over “nieuwe” kleuren: in upgrade-modus wint **behoud** van de bestaande \`config.theme\` uit de bron-JSON.\n" : ""}
${section1}

=== 2. PSYCHOLOGISCHE KLEUREN-ENGINE ===

${psychColorLead}Analyseer de branche en vul \`config.theme\` consequent in:

- Bepaal een logische **hoofdpaletrichting** (blauw = vertrouwen/IT, groen = groei/zorg, diep neutraal = luxe/legal, enz.).
- Genereer **drie tinten** als hex in JSON:
  - \`primaryLight\` — lichte achtergronden / surfaces
  - \`primaryMain\` — iconen, subtiele accenten, secundaire koppen
  - \`primaryDark\` — hover states, diepte
- **CTA / accent:** \`theme.accent\` moet **duidelijk contrasteren** met \`theme.primary\` en de achtergrond, **maar** mag **niet** automatisch oranje zijn. Gebruik §0A-accentfamilie en pas zo nodig aan op de branche. Oranje (\`#f97316\`) alleen als de sector dat inhoudelijk ondersteunt (food, bouw, aanbiedingen).
- \`theme.primary\` is de **hoofdmerk-/basis** hex die je in Tailwind-classes spiegelt (bg-*, text-*, border-*).
- **60-30-10 in de HTML:** ~60% neutraal, ~30% primaire familie, ~10% accent op CTA’s en highlights — geen enkele felle kleur over de hele viewport domineren.

${lovableThemeBlock}
=== 3. PAGINA COMPOSEREN → HTML (Tailwind) ===

Genereer een array \`sections\` — maar denk **pagina-eerst**: volg het **compositionPlan** uit het **studio-blok hierboven** (STUDIO STRUCTUUR of UPGRADE — STUDIO COMPOSER; zones, \`visual_tension\`, \`motion_personality\`, \`layout_archetype\`) en vertaal dat naar doorlopende scroll; \`sections\` zijn het **resultaat** van die compositie, geen losse stapel “blokjes”. Elke sectie: unieke, schone **Tailwind utility classes**.

- **Compositie:** laat dichtheid en rust **wisselen** zoals in het plan; één monotone rij gelijke kaarten = fout ten opzichte van de briefing.
- **Content:** wervende, Nederlandstalige teksten op basis van de omschrijving.
- **Animatie (placeholders):** HTML in iframe — **geen** React. Voeg \`data-animation\` toe (bijv. \`fade-up\`, \`slide-in-left\`, \`scale-in\`).
- **Iconen:** geen JSX. \`data-lucide="Naam"\` (PascalCase), **of** inline SVG / emoji. Varieer namen en groottes (\`w-5 h-5\` vs \`w-8 h-8\`).${section3VisualRichness}${section3Tail}${section3HeroHeight}${section3LayoutArchetypes}

${getAlpineInteractivityPromptBlock()}

=== 3B. OPERATIONELE SITE — TEKSTEN & WERKENDE LINKS (verplicht) ===

- **Copy:** **Volledige, professionele Nederlandse** zinnen (geen Lorem ipsum, geen lege placeholders) — **maar** geen **verzonnen** prijzen, kortingen, testimonials, cijfers, awards of garanties (zie **CONTENT AUTHORITY** hierboven). Headlines en USP’s: alleen claims die uit de **briefing** volgen; ontbreken die feiten → neutrale, bescheiden copy zonder fake social proof of prijzen. FAQ/footer: geen fictieve policies of stats.
- **Sectie-ankers:** Het **buitenste** element van elke sectie-\`html\` (eerste tag, meestal \`<section>\`) heeft \`id="…"\` dat **exact gelijk** is aan de JSON-\`id\` van die sectie (bijv. \`"id": "faq"\` → \`<section id="faq" class="…">\`). Zo werkt elke interne link.
- **Layout-archetype (Studio):** Als je sectie in \`_layout_archetypes\` staat: zelfde root-\`<section>\` ook \`data-layout="…"\` + binnenin \`data-slot\` op hoofdblokken volgens die map (zie STUDIO STRUCTUUR). **Upgrade:** bestaande secties **niet** herschrijven voor \`data-layout\`/\`data-slot\`; voor **nieuwe** secties volg je de map in “STUDIO COMPOSER (upgrade)” indien aanwezig.
- **Interne links (\`#…\`):** Verzamel **alle** sectie-\`id\`’s uit jouw \`sections\`-array. Elke \`<a href="#…">\` (en vergelijkbare CTA’s) mag **alleen** naar die id’s verwijzen — plus optioneel \`#top\` **als** de hero (of eerste blok) \`id="top"\` heeft. **Verboden:** \`href="#"\`, lege \`href\`, verzonnen fragmenten (\`#sectie-die-niet-bestaat\`).
- **Contact:** Zonder e-mail/telefoon in de briefing: gebruik **werkende** \`mailto:\`/\`tel:\` met **plausible** adressen afgeleid van de bedrijfsnaam (bijv. \`mailto:info@<kortenaam-zonder-spaties>.nl\`, \`tel:+3185…\` als fictief maar **geldig formaat**) **of** link naar \`#contact\` / \`#footer\` waar een duidelijk contactblok staat — geen dode knoppen.
- **WhatsApp:** Alleen \`https://wa.me/…\` als een nummer in de briefing staat; anders CTA naar \`#contact\` met copy “Neem contact op”.
- **Extern (https):** Alleen \`https://\` URL’s; gebruik **bestaande** patronen (Google Maps-zoeklink, officiële social templates) of vermijd de link en gebruik intern \`#contact\`. Geen \`http://\` zonder TLS.
- **Portaal (premium/custom):** Alleen het exacte portaal-placeholder-pad uit §0B — geen \`#\` als vervanging.
- **Knoppen:** Geen decoratieve \`<button>\` zonder actie: gebruik \`<a class="…">\` met echte \`href\` voor navigatie.
- **Nieuw tabblad:** Bij \`target="_blank"\` altijd \`rel="noopener noreferrer"\`.
${preserve ? `- **Upgrade-modus:** Bestaande sectie-\`html\` ongewijzigd laten. **Nieuwe** secties: zelfde regels (root-\`id\`, alleen geldige \`href\`). Nieuwe nav-items: verwijzen naar bestaande **of** nieuwe id’s; geen \`href="#"\`.\n` : ""}
=== 4. TECHNISCHE HTML-REGELS ===

- Tailwind + toegestane tags. **Alpine.js** (\`x-*\`, \`@\`, \`:\`) volgens het blok “INTERACTIVITEIT (Alpine.js)” hierboven. Geen \`<script>\` of \`<style>\` **in** sectie-fragmenten, geen klassieke inline event-handlers (\`onclick=\`), geen \`javascript:\` links.
- Afbeeldingen: alleen **https** met werkende URL’s — vooral \`https://images.unsplash.com/photo-…\` (echte \`photo-\` id). **Verboden:** \`example.com\`, \`via.placeholder\`, \`source.unsplash.com\`, verzonnen paden. Geen betrouwbare foto? **Geen** \`<img>\`: gebruik gradient, patroon of lege decoratieve laag i.p.v. een kapotte afbeelding.
- Fragment per sectie: geen \`<html>\` / \`<body>\` wrapper.
${section4Nav}- **Responsief:** flex/grid met breakpoints; mobiel blijft bruikbaar.

=== 5. OUTPUT-FORMAAT (strikt JSON) ===

Lever **uitsluitend** één JSON-object. Geen markdown, geen code fences, geen tekst ervoor of erna.

Structuur:

{
  "config": {
    "style": "korte naam van je gekozen visuele richting",
    "theme": {
      "primary": "#hex (merkbasis)",
      "accent": "#hex (contrasterende CTA — meestal géén standaard-oranje)",
      "primaryLight": "#hex",
      "primaryMain": "#hex",
      "primaryDark": "#hex",
      "secondary": "#hex (optioneel — zichtbaar in UI)",
      "background": "#hex (optioneel pagina/sectie-basis)",
      "textColor": "#hex (optioneel bodytekst)",
      "textMuted": "#hex (optioneel subtekst)",
      "vibe": "luxury|rustic|modern|minimal|playful|corporate|creative|warm|industrial|artisan (optioneel — alleen deze waarden)",
      "typographyStyle": "modern|elegant|bold|minimal|playful|industrial|artisan (optioneel — alleen deze waarden)",
      "borderRadius": "none|sm|md|lg|xl|2xl|full (optioneel)",
      "shadowScale": "none|sm|md|lg|xl|2xl (optioneel)",
      "spacingScale": "compact|normal|relaxed|generous (optioneel)"
    },
    "font": "CSS font-stack, bijv. Inter, system-ui, sans-serif"
  },
  "sections": [
    { "id": "hero", "html": "<section id=\\"hero\\" class=\\"...\\" data-animation=\\"fade-up\\">...</section>" },
    { "id": "features", "html": "<section id=\\"features\\" class=\\"...\\">...</section>" }
  ]
}

Minimaal deze sectie-\`id\`’s (eigen volgorde mag; volg \`_site_config.sections\`): ${requiredIdsLine}. Je mag \`name\` per sectie toevoegen (optioneel); anders wordt het label afgeleid van \`id\`.${section5IdsNote}

JSON moet geldig zijn.`;
}

export type GenerateSiteResult =
  | { ok: true; data: GeneratedTailwindPage }
  | { ok: false; error: string; rawText?: string };

export type GenerateSiteStreamHooks = {
  /** Richting browser: ruwe tekst-chunks van Claude vóór JSON-parse. */
  onTextDelta?: (chunk: string) => void;
};

type PreparedGenerateSiteClaudeCall = {
  client: Anthropic;
  model: string;
  max_tokens: number;
  system?: string;
  userContent: string | ContentBlockParam[];
  homepagePlan: HomepagePlan;
  /** Compositie + pools + conflictnotities voor admin/debug. */
  compositionDebug?: CompositionDebugPayload;
  /** Gegenereerd vóór de site-call; wordt aan het resultaat geplakt. */
  precomputedLogoSet?: GeneratedLogoSet;
};

type PrepareGenerateSiteResult = PreparedGenerateSiteClaudeCall | { ok: false; error: string };

type ClaudeTextStreamEvent =
  | { type: "delta"; text: string }
  | { type: "end"; usage: MessageDeltaUsage | null; stop_reason: string | null };

async function* streamClaudeMessageText(
  client: Anthropic,
  input: {
    model: string;
    max_tokens: number;
    system?: string;
    userContent: string | ContentBlockParam[];
  },
): AsyncGenerator<ClaudeTextStreamEvent> {
  const userContent =
    typeof input.userContent === "string" ? input.userContent : input.userContent;

  const stream = await client.messages.create({
    model: input.model,
    max_tokens: input.max_tokens,
    stream: true,
    ...(input.system ? { system: input.system } : {}),
    messages: [{ role: "user", content: userContent }],
  });

  let usage: MessageDeltaUsage | null = null;
  let stop_reason: string | null = null;

  for await (const event of stream) {
    if (event.type === "content_block_delta" && event.delta.type === "text_delta") {
      yield { type: "delta", text: event.delta.text };
    } else if (event.type === "message_delta") {
      usage = event.usage;
      stop_reason = event.delta.stop_reason;
    }
  }

  yield { type: "end", usage, stop_reason };
}

async function prepareGenerateSiteClaudeCall(
  businessName: string,
  description: string,
  recentClientNames: string[],
  promptOptions?: GenerateSitePromptOptions,
): Promise<PrepareGenerateSiteResult> {
  const apiKey = getAnthropicApiKey();
  if (!apiKey) {
    return {
      ok: false,
      error: `ANTHROPIC_API_KEY ontbreekt in de omgeving. ${ANTHROPIC_KEY_MISSING_USER_HINT}`,
    };
  }

  const model = process.env.ANTHROPIC_MODEL ?? DEFAULT_MODEL;
  const client = new Anthropic({ apiKey });

  const { systemText: knowledgeSystem, userPrefixBlocks } = await getKnowledgeContextForClaude();

  const preserveLayout = Boolean(promptOptions?.preserveLayoutUpgrade);
  const mergedPromptOptions: GenerateSitePromptOptions = {
    ...promptOptions,
    /** Altijd een nonce (ook bij upgrade): layout-map pick + anti-generieke copy varieert per run. */
    varianceNonce: promptOptions?.varianceNonce ?? randomUUID(),
  };

  const userPromptForConfig = `Bedrijfsnaam: ${businessName.trim()}\n\nBriefing / branche:\n${description.trim()}`;
  let siteConfig = await buildSiteConfig(userPromptForConfig);
  let extractedFromImage: ExtractedDesignFromImage | null = null;

  if (!preserveLayout) {
    const refImageUrl = findFirstKnowledgeImageUrl(userPrefixBlocks);
    if (refImageUrl && process.env.DISABLE_DESIGN_EXTRACT !== "1") {
      const extracted = await extractDesignFromImage(refImageUrl);
      if (extracted.ok) {
        extractedFromImage = extracted.data;
        siteConfig = mergeExtractedDesignIntoSiteConfig(siteConfig, extracted.data);
      }
    }
  }

  let homepageCompactnessPlan: HomepageCompactnessPlan | undefined;
  if (!preserveLayout) {
    homepageCompactnessPlan = buildHomepageCompactnessPlan(siteConfig);
    siteConfig = applyHomepageCompactnessToSiteConfig(siteConfig, homepageCompactnessPlan);
  }

  const upgradeJson = promptOptions?.existingSiteTailwindJson?.trim() ?? "";
  const sectionIdsFromExistingSite =
    preserveLayout && upgradeJson ? extractSectionIdsFromTailwindUpgradeJson(upgradeJson) : null;
  let siteConfigForStudio: SiteConfig = {
    ...siteConfig,
    sections: mergeUpgradeSectionOrder(sectionIdsFromExistingSite, siteConfig.sections),
  };

  const composition = resolveCompositionPlan({ siteIntent: siteConfigForStudio.site_intent });
  siteConfig = { ...siteConfig, site_intent: composition.normalizedSiteIntent };
  siteConfigForStudio = {
    ...siteConfigForStudio,
    site_intent: composition.normalizedSiteIntent,
  };

  const homepagePlan = buildHomepagePlan(
    composition.normalizedSiteIntent,
    userPromptForConfig,
    composition.pageCompositionBias.rhythmBias,
  );
  const homepagePlanIssues = validateHomepagePlan(homepagePlan);

  const designPreset = getDesignPreset(siteConfig.brand_style);
  const poolDebug: NonNullable<CompositionDebugPayload["poolDebug"]> = {};
  const { components, layoutArchetypes } = buildStudioPromptLayoutMaps(
    siteConfigForStudio,
    mergedPromptOptions.varianceNonce ?? "",
    {
      themeMode: designPreset.themeMode,
      personality: siteConfigForStudio.personality,
      varianceNonce: mergedPromptOptions.varianceNonce,
      freeformSectionFraction: preserveLayout ? 0 : 0.28,
      homepagePlan,
      layoutOptions: composition.layoutOptions,
      pageCompositionBias: composition.pageCompositionBias,
      poolDebugOut: poolDebug,
    },
  );

  const decisionTrace = buildCompositionDecisionTrace({
    normalizedSiteIntent: composition.normalizedSiteIntent,
    layoutOptions: composition.layoutOptions,
    finalDesignRegime: resolveFinalDesignRegime(composition.normalizedSiteIntent),
    effectiveHeroExpression: getEffectiveHeroExpression(composition.normalizedSiteIntent),
    conflictDecisions: composition.conflictDecisions,
    compactPromptUsed: composition.layoutOptions.preferCompactFallbackPrompt,
  });

  const compositionDebug = buildCompositionDebugPayload({
    siteIntent: composition.normalizedSiteIntent,
    layoutOptions: composition.layoutOptions,
    pageCompositionBias: composition.pageCompositionBias,
    conflictsResolved: composition.conflictsResolved,
    conflictDecisions: composition.conflictDecisions,
    decisionTrace,
    poolDebug,
  });

  if (process.env.NODE_ENV === "development") {
    console.info("[compositionDebug]", JSON.stringify(compositionDebug, null, 2));
  }

  const structureLayer = preserveLayout
    ? buildStudioStructurePromptBlockForUpgrade({
        siteConfig: siteConfigForStudio,
        components,
        layoutArchetypes,
        siteIntent: siteConfigForStudio.site_intent,
        homepagePlan,
        homepagePlanIssues,
        layoutOptions: composition.layoutOptions,
        compositionConflictsResolved: composition.conflictsResolved,
        compositionConflictDecisions: composition.conflictDecisions,
      })
    : buildStudioStructurePromptBlock({
        siteConfig: siteConfigForStudio,
        components,
        layoutArchetypes,
        designPreset,
        extractedFromImage,
        siteIntent: siteConfigForStudio.site_intent,
        homepagePlan,
        homepagePlanIssues,
        layoutOptions: composition.layoutOptions,
        compositionConflictsResolved: composition.conflictsResolved,
        compositionConflictDecisions: composition.conflictDecisions,
      });

  const maxTokensRaw = Number.parseInt(process.env.ANTHROPIC_MAX_OUTPUT_TOKENS ?? "", 10);
  const max_tokens = Number.isFinite(maxTokensRaw) && maxTokensRaw >= 4096
    ? Math.min(maxTokensRaw, 64_000)
    : DEFAULT_MAX_OUTPUT_TOKENS;

  let precomputedLogoSet: GeneratedLogoSet | undefined;
  let brandLogoAppendix = "";
  if (isBrandLogoSystemEnabled() && !preserveLayout) {
    const logoRun = await runPremiumLogoPipeline({
      businessName: businessName.trim(),
      description: description.trim(),
      siteConfig,
    });
    if (logoRun.ok) {
      precomputedLogoSet = logoRun.data;
      brandLogoAppendix = buildBrandLogoPromptAppendix(logoRun.data);
    } else if (process.env.NODE_ENV === "development") {
      console.warn("[ENABLE_BRAND_LOGO_SYSTEM]", logoRun.error);
    }
  }

  const corePrompt = buildWebsiteGenerationUserPrompt(
    businessName,
    description,
    recentClientNames,
    {
      ...mergedPromptOptions,
      sectionIdsHint: siteConfigForStudio.sections,
      copyContext: {
        personality: siteConfig.personality,
        targetAudience: siteConfig.target_audience,
        primaryGoal: siteConfig.primary_goal,
        brandStyle: siteConfig.brand_style,
      },
    },
  );
  let mainUserPrompt = structureLayer ? `${structureLayer}\n\n${corePrompt}` : corePrompt;
  if (!preserveLayout && homepageCompactnessPlan) {
    mainUserPrompt = `${buildCompactnessPromptBlock(homepageCompactnessPlan)}\n\n${mainUserPrompt}`;
  }
  if (brandLogoAppendix.trim() !== "") {
    mainUserPrompt = `${mainUserPrompt}\n\n${brandLogoAppendix}`;
  }

  const userContent: string | ContentBlockParam[] =
    userPrefixBlocks.length > 0
      ? [...userPrefixBlocks, { type: "text", text: `\n\n=== OPDRACHT (site-generatie) ===\n\n${mainUserPrompt}` }]
      : mainUserPrompt;

  const systemParts = [MASTER_SITE_SYSTEM_PROMPT];
  if (knowledgeSystem?.trim()) {
    systemParts.push(knowledgeSystem.trim());
  }
  const system = systemParts.join("\n\n---\n\n");

  return {
    client,
    model,
    max_tokens,
    system,
    userContent,
    homepagePlan,
    compositionDebug: compositionDebug,
    ...(precomputedLogoSet != null ? { precomputedLogoSet } : {}),
  };
}

/** Voegt heuristische claim-scan toe voor admin UI (niet voor opslag). */
export function withContentClaimDiagnostics(data: GeneratedTailwindPage): GeneratedTailwindPage {
  const html = data.sections.map((s) => s.html).join("\n");
  return {
    ...data,
    contentClaimDiagnostics: buildContentClaimDiagnosticsReport(html),
  };
}

function finalizeGenerateSiteFromClaudeText(
  textBody: string,
  stop_reason: string | null,
): GenerateSiteResult {
  if (!textBody.trim()) {
    return { ok: false, error: "Geen tekst-antwoord van Claude ontvangen." };
  }

  const parsedResult = parseModelJsonObject(textBody);
  if (!parsedResult.ok) {
    const truncated =
      stop_reason === "max_tokens"
        ? " Het antwoord werd afgekapt (max_tokens). Verhoog ANTHROPIC_MAX_OUTPUT_TOKENS of verkort de briefing."
        : "";
    return {
      ok: false,
      error: `Antwoord is geen geldige JSON.${truncated}`,
      rawText: textBody,
    };
  }

  const validated = claudeTailwindPageOutputSchema.safeParse(parsedResult.value);
  if (!validated.success) {
    return {
      ok: false,
      error: `JSON voldoet niet aan het schema: ${validated.error.message}`,
      rawText: textBody,
    };
  }

  const processed = postProcessClaudeTailwindPage(validated.data);
  return { ok: true, data: mapClaudeOutputToSections(processed) };
}

export async function generateSiteWithClaude(
  businessName: string,
  description: string,
  recentClientNames: string[] = [],
  promptOptions?: GenerateSitePromptOptions,
  streamHooks?: GenerateSiteStreamHooks,
): Promise<GenerateSiteResult> {
  const prepared = await prepareGenerateSiteClaudeCall(businessName, description, recentClientNames, promptOptions);

  if ("ok" in prepared && prepared.ok === false) {
    return { ok: false, error: prepared.error };
  }

  const p = prepared as PreparedGenerateSiteClaudeCall;

  let textBody = "";
  let usage: MessageDeltaUsage | null = null;
  let stop_reason: string | null = null;

  try {
    for await (const ev of streamClaudeMessageText(p.client, {
      model: p.model,
      max_tokens: p.max_tokens,
      system: p.system,
      userContent: p.userContent,
    })) {
      if (ev.type === "delta") {
        textBody += ev.text;
        streamHooks?.onTextDelta?.(ev.text);
      } else {
        usage = ev.usage;
        stop_reason = ev.stop_reason;
      }
    }
  } catch (e) {
    const msg = e instanceof Error ? e.message : "Claude-streaming mislukt.";
    return { ok: false, error: msg };
  }

  if (usage) {
    await logClaudeMessageUsage("generate_site", p.model, {
      input_tokens: usage.input_tokens ?? 0,
      output_tokens: usage.output_tokens,
      cache_creation_input_tokens: usage.cache_creation_input_tokens,
      cache_read_input_tokens: usage.cache_read_input_tokens,
    });
  }

  const result = finalizeGenerateSiteFromClaudeText(textBody, stop_reason);
  if (!result.ok) {
    return result;
  }

  let data = withContentClaimDiagnostics(result.data);
  if (p.precomputedLogoSet) {
    data = { ...data, logoSet: p.precomputedLogoSet };
  }

  if (process.env.NODE_ENV === "development") {
    const joined = data.sections.map((s) => s.html).join("\n");
    const v = validateGeneratedPageHtml(joined, p.homepagePlan);
    if (v.errors.length > 0 || v.warnings.length > 0) {
      console.warn("[validateGeneratedPageHtml]", v);
    }
  }

  return { ok: true, data };
}

export type GenerateSiteStreamNdjsonEvent =
  | { type: "status"; message: string }
  | { type: "token"; content: string }
  | { type: "section_complete"; section: { id: string; html: string; sectionName?: string } }
  | { type: "complete"; data: GeneratedTailwindPage }
  | { type: "error"; message: string; rawText?: string };

export type CreateGenerateSiteReadableStreamOptions = {
  /** O.a. activity journal na geslaagde validatie, vóór `complete`-event. */
  onSuccess?: (data: GeneratedTailwindPage) => Promise<void>;
};

/**
 * NDJSON-stream (één JSON-object per regel) voor de browser: status, tokens, optioneel section_complete, complete/error.
 */
export function createGenerateSiteReadableStream(
  businessName: string,
  description: string,
  recentClientNames: string[],
  promptOptions?: GenerateSitePromptOptions,
  streamOptions?: CreateGenerateSiteReadableStreamOptions,
): ReadableStream<Uint8Array> {
  const encoder = new TextEncoder();
  const send = (controller: ReadableStreamDefaultController<Uint8Array>, event: GenerateSiteStreamNdjsonEvent) => {
    controller.enqueue(encoder.encode(`${JSON.stringify(event)}\n`));
  };

  return new ReadableStream({
    async start(controller) {
      try {
        send(controller, { type: "status", message: "Generatie gestart" });

        const prepared = await prepareGenerateSiteClaudeCall(
          businessName,
          description,
          recentClientNames,
          promptOptions,
        );

        if ("ok" in prepared && prepared.ok === false) {
          send(controller, { type: "error", message: prepared.error });
          controller.close();
          return;
        }

        const p = prepared as PreparedGenerateSiteClaudeCall;
        let buffer = "";
        const sentSectionIds = new Set<string>();
        let extractTick = 0;
        let usage: MessageDeltaUsage | null = null;
        let stop_reason: string | null = null;

        for await (const ev of streamClaudeMessageText(p.client, {
          model: p.model,
          max_tokens: p.max_tokens,
          system: p.system,
          userContent: p.userContent,
        })) {
          if (ev.type === "delta") {
            buffer += ev.text;
            send(controller, { type: "token", content: ev.text });
            extractTick += 1;
            if (buffer.length < 120_000 || extractTick % 14 === 0) {
              const { newSections } = tryExtractCompletedSections(buffer, sentSectionIds);
              for (const section of newSections) {
                send(controller, { type: "section_complete", section });
              }
            }
          } else {
            usage = ev.usage;
            stop_reason = ev.stop_reason;
          }
        }

        if (usage) {
          await logClaudeMessageUsage("generate_site", p.model, {
            input_tokens: usage.input_tokens ?? 0,
            output_tokens: usage.output_tokens,
            cache_creation_input_tokens: usage.cache_creation_input_tokens,
            cache_read_input_tokens: usage.cache_read_input_tokens,
          });
        }

        const result = finalizeGenerateSiteFromClaudeText(buffer, stop_reason);
        if (!result.ok) {
          send(controller, {
            type: "error",
            message: result.error,
            ...(result.rawText ? { rawText: result.rawText } : {}),
          });
          controller.close();
          return;
        }

        let data = withContentClaimDiagnostics(result.data);
        if (p.precomputedLogoSet) {
          data = { ...data, logoSet: p.precomputedLogoSet };
        }

        if (process.env.NODE_ENV === "development") {
          const joined = data.sections.map((s) => s.html).join("\n");
          const v = validateGeneratedPageHtml(joined, p.homepagePlan);
          if (v.errors.length > 0 || v.warnings.length > 0) {
            console.warn("[validateGeneratedPageHtml]", v);
          }
        }

        await streamOptions?.onSuccess?.(data);

        send(controller, { type: "complete", data });
        send(controller, { type: "status", message: "Generatie voltooid" });
        controller.close();
      } catch (error) {
        send(controller, {
          type: "error",
          message: error instanceof Error ? error.message : "Onbekende fout",
        });
        controller.close();
      }
    },
  });
}

/** Alias (API-naam uit ontwerp). */
export function generateSiteWithClaudeStreaming(
  businessName: string,
  description: string,
  recentClientNames: string[],
  promptOptions?: GenerateSitePromptOptions,
  streamOptions?: CreateGenerateSiteReadableStreamOptions,
): ReadableStream<Uint8Array> {
  return createGenerateSiteReadableStream(businessName, description, recentClientNames, promptOptions, streamOptions);
}

export type { GeneratedTailwindPage, MasterPromptPageConfig, TailwindSection };
