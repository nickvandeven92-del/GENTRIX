/**
 * Korte goed/slecht voorbeelden — generiek, zonder merknamen of productclaims (prompt-only).
 * Klein gehouden i.v.m. context-tokens.
 */
export const LOVABLE_EXAMPLES_COMPACT = `
=== LOVABLE vs BORING (patterns, not literal copy) ===

**Do (high-end):**
- Hero: minstens \`text-5xl\`–\`text-8xl\` op desktop voor hoofdkop (standaard Tailwind scale); \`tracking-tight\` / \`leading-tight\` waar het past.
- Minstens één sectie met **ongelijk grid** of **open editorial band** (sterke kop + witruimte + beeld/full-bleed) — geen drie identieke “icoon-in-kader”-kolommen zonder hiërarchie.
- Diepte op **grote vlakken** (sectie-wrapper met preset \`effects.*\` / gradient), **niet** door elke alinea in een \`rounded-2xl border shadow\`-doos te stoppen.
- Achtergrondlaag: gradient en/of \`blur-3xl\` orbs + preset \`effects.*\` — geen kale \`bg-white\` over de hele pagina zonder diepte of typografisch anker.
- Optioneel: één **stille** loop-video (\`muted playsinline autoplay loop\`, \`https://\`) als hero-drama i.p.v. extra stock-foto’s — max. één, geen geluid.
- Concrete bewijsregels in copy (jaren, aantallen, certificaten) i.p.v. “wij zijn de beste”.

**Don’t (instant generic):**
- Openen met “Welkom bij [bedrijf]” als eerste zin van de hero.
- Drie gelijke “icoon + titel + zinnetje” cards als enige features-patroon.
- **Border+shadow+rond** op elk blok als enige manier om inhoud te groeperen (voelt als standaard Tailwind-SaaS).
- Alleen \`rounded-lg\` overal — wissel \`rounded-none\`, \`rounded-2xl\`, \`rounded-full\` bewust.
- Bodytekst \`text-gray-400\`/\`text-gray-500\` op donkere achtergronden voor lange alinea’s.

**Technical:** gebruik standaard Tailwind-utilities en \`_design_preset\` strings — geen willekeurige bracket-waarden (\`w-[333px]\`, \`text-[13px]\`, \`rounded-[2rem]\`) tenzij exact zo in een preset-string staat.
`.trim();
