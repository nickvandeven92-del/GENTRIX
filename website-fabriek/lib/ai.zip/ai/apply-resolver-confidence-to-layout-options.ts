import type { ResolverConfidence } from "@/lib/ai/site-experience-model";

export type LayoutBiasStrength = "soft" | "balanced" | "hard";

export type ResolverConfidenceLayoutOptions = {
  biasStrength: LayoutBiasStrength;
  allowAggressiveNarrowing: boolean;
  allowArchetypeHardFilter: boolean;
  preferCompactFallbackPrompt: boolean;
};

/**
 * Zet resolver-betrouwbaarheid om in operationele layout/prompt-strengheid. Puur, geen side effects.
 */
export function applyResolverConfidenceToLayoutOptions(
  confidence?: ResolverConfidence | null,
): ResolverConfidenceLayoutOptions {
  if (!confidence) {
    return {
      biasStrength: "balanced",
      allowAggressiveNarrowing: false,
      allowArchetypeHardFilter: false,
      preferCompactFallbackPrompt: false,
    };
  }

  const { level, score } = confidence;

  if (level === "high" || score >= 0.8) {
    return {
      biasStrength: "hard",
      allowAggressiveNarrowing: true,
      allowArchetypeHardFilter: true,
      preferCompactFallbackPrompt: false,
    };
  }

  if (level === "low" || score < 0.45) {
    return {
      biasStrength: "soft",
      allowAggressiveNarrowing: false,
      allowArchetypeHardFilter: false,
      preferCompactFallbackPrompt: true,
    };
  }

  return {
    biasStrength: "balanced",
    allowAggressiveNarrowing: false,
    allowArchetypeHardFilter: false,
    preferCompactFallbackPrompt: false,
  };
}
