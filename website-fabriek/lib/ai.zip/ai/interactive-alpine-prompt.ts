/**
 * Gedeelde prompttekst: Studio laadt Alpine.js 3 op preview, publicatie en export (tailwind_cdn).
 * Houd dit synchroon met lib/site/studio-alpine-cdn.ts en sanitize in tailwind-page-html.
 */
export function getAlpineInteractivityPromptBlock(): string {
  return `=== INTERACTIVITEIT (Alpine.js 3, CDN) ===
De pagina laadt **Alpine.js** naast Tailwind. Gebruik **declaratieve** micro-interacties in elk \`html\`-fragment waar dat de UX merkbaar verbetert (FAQ-uitklap, mobiel menu, tabs) — niet overal tóévoegen.

**Toegestaan in \`html\`:** \`x-data="…"\` (compacte state, JSON-achtig), \`x-show\`, \`x-cloak\`, \`x-transition\`, \`x-for\` (vaak op \`<template x-for="…">\`), \`x-model\`, \`x-text\`, \`x-bind\` en korte vorm \`:class\`, \`:id\`, \`x-on:click\` of \`@click\`, \`@submit.prevent\`, enz.

**Verboden in fragmenten:** eigen \`<script>\` of \`<style>\`, klassieke inline handlers (\`onclick=\`, \`onchange=\`), \`javascript:\` links, en **\`x-html\`** (wordt uit sanitisatie verwijderd — gebruik \`x-text\` of vaste markup).

**Formulieren:** \`<form>\` met \`@submit.prevent\` mag voor UX (bijv. “bedankt”-toggle); echte server-POST is niet standaard — gebruik \`mailto:\`, \`tel:\`, \`https://\` of ankers naar \`#contact\` tenzij de briefing expliciet anders vraagt. Geen fictieve API-routes als harde afhankelijkheid.`;
}
