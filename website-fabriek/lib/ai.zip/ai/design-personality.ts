import { z } from "zod";

/**
 * Stuurrichting voor layout-pools + promptregels.
 * Geen verwijzing naar concrete merken — alleen stijlkenmerken (juridisch veiliger dan “doe X als merk Y”).
 */
export const DESIGN_PERSONALITY_VALUES = [
  "bold_industrial",
  "elegant_luxury",
  "playful_creative",
  "minimal_tech",
  "editorial_art",
  "trust_conversion",
] as const;

export type DesignPersonality = (typeof DESIGN_PERSONALITY_VALUES)[number];

export const designPersonalitySchema = z.enum(DESIGN_PERSONALITY_VALUES);

export const PERSONALITY_RULES: Record<DesignPersonality, string> = {
  bold_industrial: `
- Sterke koppen (uppercase waar het past bij de toon), monospace voor cijfers/statistieken.
- Donkere basis + één felle accent (amber / oranje / rood) — geen pastel.
- Asymmetrie, overlap, robuuste fotografie (detail, proces, materiaal).
- Geen zachte verloop-overload; wel harde contrasten en duidelijke rasterbreuk.
`.trim(),
  elegant_luxury: `
- Combinatie serif (koppen) + sans (body) of omgekeerd, consistent door de pagina.
- Italic voor tagline/citaat; zachte gradients of dunne borders; royale witruimte.
- Donker + goud/brons, of licht + taupe/zilver — premium timing, geen speelgoedkleuren.
- Afgeronde hoeken in lg–xl range; subtiele schaduwen.
`.trim(),
  playful_creative: `
- Varierende schaal, felle maar gecontroleerde accenten (roze, geel, mint, paars — kies 1–2).
- Afgeronde knoppen (rounded-full), decoratieve cirkels/badges; bento of gebroken grid.
- Illustratieve of kleurrijke beelden; mag onverwacht, maar blijf leesbaar.
`.trim(),
  minimal_tech: `
- Strak sans-serif, duidelijke hiërarchie; max. twee neutrale families + één accentkleur.
- Veel verticale lucht; dunne lijnen; productbeeld op neutrale achtergrond.
- Radius meestal none–md; weinig decoratie, wél sterke typografie.
`.trim(),
  editorial_art: `
- Expressieve typografie (mixed case), magazine-achtige grids, tekst over beeld in hero.
- Portret- en sfeerbeelden; durf witruimte en ongelijke kolommen.
- **Canvas-gedrag:** secties mogen “open” aanvoelen (geen kader om elke paragraaf); gebruik lijnen/borders spaarzaam; hiërarchie via schaal en ritme.
`.trim(),
  trust_conversion: `
- Functioneel, scanbaar; social proof groot (cijfers, reviews, logo’s, guarantees).
- Checkmarks/badges; meerdere duidelijke CTA’s; hoge contrast op acties.
- Geen gimmicks die vertrouwen ondermijnen.
`.trim(),
};

export function formatPersonalityPromptBlock(personality: DesignPersonality): string {
  return `=== DESIGN PERSONALITY (hard — match _site_config.personality) ===

**personality:** \`${personality}\`

**Rules for this run (apply in copy, composition, and Tailwind):**

${PERSONALITY_RULES[personality]}
`;
}
